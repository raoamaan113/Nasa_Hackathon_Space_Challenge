import { BrowserRouter, Routes, Route, Navigate, NavLink } from 'react-router-dom'
import { LayoutDashboard, Activity, ClipboardCheck, UserRound, BookOpen, FileText, Orbit, WifiOff } from 'lucide-react'

import { CrewProvider, useCrew } from './context/Crew'
import Dashboard from './pages/Dashboard'
import Monitoring from './pages/Monitoring'
import Assessment from './pages/Assessment'
import HumanBody from './pages/HumanBody'
import Guidance from './pages/Guidance'
import Reports from './pages/Reports'

const navigation = [
  { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
  { name: 'Monitoring', path: '/monitoring', icon: Activity },
  { name: 'Assessment', path: '/assessment', icon: ClipboardCheck },
  { name: 'Human Body', path: '/human-body', icon: UserRound },
  { name: 'Guidance & AI', path: '/guidance', icon: BookOpen },
  { name: 'Reports', path: '/reports', icon: FileText },
]

function AppLayout() {
  const { crew, astronaut, selectedId, select, online } = useCrew()

  return (
    <div className="min-h-screen bg-[#080d19] text-slate-100">
      <aside className="fixed left-0 top-0 z-20 hidden h-screen w-64 flex-col border-r border-slate-800 bg-[#0c1424] p-5 lg:flex">
        <div className="mb-10 flex items-center gap-3">
          <div className="rounded-xl bg-cyan-400/10 p-3"><Orbit size={25} className="text-cyan-400" /></div>
          <div>
            <h1 className="text-xl font-bold tracking-wider">ASTRA<span className="text-cyan-400">HEALTH</span></h1>
            <p className="text-xs text-slate-500">SPACE HEALTH SYSTEM</p>
          </div>
        </div>

        <p className="mb-4 text-xs font-semibold uppercase tracking-widest text-slate-500">Main Menu</p>
        <nav className="flex flex-col gap-2">
          {navigation.map(({ name, path, icon: Icon }) => (
            <NavLink key={path} to={path} className={({ isActive }) =>
              `flex items-center gap-3 rounded-xl px-4 py-3 text-sm transition ${isActive ? 'bg-cyan-400/10 text-cyan-400' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
              <Icon size={19} />{name}
            </NavLink>
          ))}
        </nav>

        <div className="mt-auto rounded-xl border border-slate-800 p-4">
          <p className="text-xs text-slate-500">SYSTEM STATUS</p>
          <p className={`mt-2 font-semibold ${online === false ? 'text-red-400' : online ? 'text-emerald-400' : 'text-slate-400'}`}>
            {online === false ? 'Backend unreachable' : online ? 'System Online' : 'Connecting…'}
          </p>
          <p className="mt-1 text-xs text-slate-500">On-board record · works without a ground link</p>
        </div>
      </aside>

      <div className="min-h-screen lg:ml-64">
        <header className="flex min-h-20 flex-wrap items-center justify-between gap-3 border-b border-slate-800 px-4 py-3 sm:px-8">
          <div>
            <p className="text-xs uppercase tracking-widest text-slate-500">Mission Control / ASTRA</p>
            <h2 className="mt-1 font-semibold">Astronaut Health Monitoring</h2>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <label htmlFor="crew" className="block text-xs text-slate-500">Crew member</label>
              <select id="crew" value={selectedId || ''} onChange={(e) => select(e.target.value)}
                className="mt-1 rounded-lg border border-slate-700 bg-[#0c1424] px-3 py-1.5 text-sm text-white outline-none focus:border-cyan-400">
                {crew.map((a) => <option key={a.id} value={a.id}>{a.id} · {a.name}</option>)}
              </select>
            </div>
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-cyan-400/10 text-cyan-400" title={astronaut?.name}>
              <UserRound size={20} />
            </div>
          </div>
        </header>

        {/* compact nav for small screens */}
        <nav className="flex gap-2 overflow-x-auto border-b border-slate-800 px-4 py-2 lg:hidden">
          {navigation.map(({ name, path }) => (
            <NavLink key={path} to={path} className={({ isActive }) =>
              `whitespace-nowrap rounded-lg px-3 py-1.5 text-sm ${isActive ? 'bg-cyan-400/10 text-cyan-400' : 'text-slate-400'}`}>{name}</NavLink>
          ))}
        </nav>

        <main className="p-4 sm:p-8">
          {online === false ? (
            <div className="mx-auto mt-16 max-w-lg rounded-2xl border border-red-400/30 bg-red-400/5 p-8 text-center">
              <WifiOff className="mx-auto text-red-400" size={34} />
              <h2 className="mt-4 text-xl font-semibold">Cannot reach the ASTRA-HEALTH backend</h2>
              <p className="mt-2 text-sm text-slate-400">Start it with <code className="text-cyan-400">python -m uvicorn app.main:app</code> in the <code className="text-cyan-400">backend</code> folder, then reload this page.</p>
            </div>
          ) : !selectedId ? (
            <p className="p-6 text-sm text-slate-400">Loading crew…</p>
          ) : (
            <Routes>
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/monitoring" element={<Monitoring />} />
              <Route path="/assessment" element={<Assessment />} />
              <Route path="/human-body" element={<HumanBody />} />
              <Route path="/guidance" element={<Guidance />} />
              <Route path="/reports" element={<Reports />} />
              <Route path="*" element={<Navigate to="/dashboard" replace />} />
            </Routes>
          )}
          <p className="mt-10 text-center text-xs text-slate-600">
            Decision support only — not a medical diagnosis. Vital-sign data in this prototype is simulated.
          </p>
        </main>
      </div>
    </div>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <CrewProvider><AppLayout /></CrewProvider>
    </BrowserRouter>
  )
}
