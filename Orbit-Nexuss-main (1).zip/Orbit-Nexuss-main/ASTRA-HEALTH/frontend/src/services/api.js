import axios from 'axios'

// Same origin by default (FastAPI serves the UI). Set VITE_API_BASE_URL to point at another host.
const http = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || '',
  timeout: 60000,
  headers: { 'Content-Type': 'application/json' },
})

const get = (url, params) => http.get(url, { params }).then((r) => r.data)
const post = (url, body) => http.post(url, body).then((r) => r.data)
const v1 = '/api/v1'

export const api = {
  baseURL: http.defaults.baseURL,
  health: () => get('/health'),
  astronauts: () => get(`${v1}/astronauts`),
  createAstronaut: (body) => post(`${v1}/astronauts`, body),
  crewOverview: () => get(`${v1}/crew/overview`),
  dashboard: (id) => get(`${v1}/astronauts/${id}/dashboard`),
  series: (id, metric, days = 30) => get(`${v1}/astronauts/${id}/series/${metric}`, { days }),
  readings: (id, days = 1000) => get(`${v1}/astronauts/${id}/readings`, { days }),
  alerts: (id, days = 7) => get(`${v1}/astronauts/${id}/alerts`, { days }),
  logReading: (body) => post(`${v1}/readings`, body),
  telemetry: (samples) => post(`${v1}/telemetry`, { samples }),
  symptoms: (id) => get(`${v1}/astronauts/${id}/symptoms`),
  addSymptom: (body) => post(`${v1}/symptoms`, body),
  wellbeingQuestions: () => get(`${v1}/wellbeing/questions`),
  addWellbeing: (body) => post(`${v1}/wellbeing`, body),
  chat: (body) => post(`${v1}/assistant/chat`, body),
  summary: (id) => get(`${v1}/astronauts/${id}/summary`),
  assistantStatus: () => get(`${v1}/assistant/status`),
  mlMetrics: () => get(`${v1}/ml/metrics`),
  standards: () => get(`${v1}/reference/standards`),
  nasaStudy: () => get(`${v1}/reference/nasa-study`),
  exportUrl: (id, format) => `${http.defaults.baseURL}${v1}/astronauts/${id}/export?format=${format}`,
}

export const errorText = (e) => {
  const d = e?.response?.data?.detail
  if (Array.isArray(d)) return d.map((x) => `${x.loc?.slice(-1)[0]}: ${x.msg}`).join('; ')
  return d || e?.message || 'Request failed'
}

export default api
