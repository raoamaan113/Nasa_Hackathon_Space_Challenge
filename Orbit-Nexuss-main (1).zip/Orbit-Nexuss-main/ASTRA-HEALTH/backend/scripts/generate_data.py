"""Generate a realistic synthetic long-duration mission health dataset.

Design goals (what makes it "near real"):
  * Each astronaut has a personal physiological baseline.
  * Microgravity adaptation: early fluid shift, cardiovascular deconditioning,
    ~1-1.5 %/month bone loss that is mitigated by exercise.
  * Behavioural health: a mid-mission "third-quarter" dip in mood and sleep.
  * Sleep -> stress -> heart-rate couplings are calibrated on the Kaggle
    "Sleep Health and Lifestyle" reference table when it is available.
  * The cabin environment (CO2, temperature, radiation, solar particle events)
    is SHARED by the whole crew on a given day.
  * Medical events are multi-day EPISODES with an onset ramp, not single spikes,
    so early-warning detection is meaningful.

Usage:  python scripts/generate_data.py [--crew 24] [--days 180] [--seed 7]
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
REFERENCE = ROOT / "data" / "reference" / "sleep_health_lifestyle_kaggle.csv"
OUTPUT = ROOT / "data" / "astronaut_health.csv"

# (name, daily start probability, (min_days, max_days))
EPISODES = [
    ("tachycardia", 0.006, (1, 2)),
    ("fever", 0.005, (3, 5)),
    ("hypertension", 0.005, (2, 4)),
    ("hyperglycemia", 0.004, (1, 2)),
    ("sleep_deprivation_low_mood", 0.006, (3, 6)),
]
LABEL_INTENSITY = 0.4  # episode days below this intensity stay labelled "normal" (prodrome)


def calibrate_couplings() -> dict[str, float]:
    """Fit simple linear couplings on the reference table (falls back to defaults)."""
    defaults = {"stress_per_sleep_h": -1.6, "hr_per_stress": 1.5, "quality_per_sleep_h": 1.3}
    if not REFERENCE.exists():
        return defaults
    ref = pd.read_csv(REFERENCE)
    slope = lambda x, y: float(np.polyfit(ref[x], ref[y], 1)[0])  # noqa: E731
    return {
        "stress_per_sleep_h": slope("Sleep Duration", "Stress Level"),
        "hr_per_stress": slope("Stress Level", "Heart Rate"),
        "quality_per_sleep_h": slope("Sleep Duration", "Quality of Sleep"),
    }


def episode_profile(length: int) -> np.ndarray:
    """Intensity 0..1 per day: ramp up, plateau, ramp down."""
    if length == 1:
        return np.array([1.0])
    x = np.linspace(0, np.pi, length + 2)[1:-1]
    return np.clip(np.sin(x) * 1.15, 0, 1)


def simulate_environment(days: int, rng: np.random.Generator) -> pd.DataFrame:
    """Cabin environment shared by the whole crew."""
    co2 = 2.6 + np.zeros(days)
    noise = 0.0
    for d in range(days):  # AR(1) noise: CO2 drifts, it does not jump randomly
        noise = 0.7 * noise + rng.normal(0, 0.22)
        co2[d] += noise
    co2_event = np.zeros(days)
    for start in rng.choice(np.arange(10, days - 3), size=max(2, days // 45), replace=False):
        length = int(rng.integers(1, 4))
        prof = episode_profile(length) * rng.uniform(3.0, 5.0)
        co2_event[start:start + length] = np.maximum(co2_event[start:start + length], prof[: days - start])
    dose = rng.normal(0.60, 0.05, days).clip(0.4)  # mSv/day, ISS-like
    spe = np.zeros(days, dtype=int)
    for start in rng.choice(np.arange(15, days - 2), size=max(1, days // 80), replace=False):
        dose[start] += rng.uniform(6, 18)       # solar particle event
        dose[start + 1] += rng.uniform(1, 4)
        spe[start:start + 2] = 1
    return pd.DataFrame({
        "mission_day": np.arange(1, days + 1),
        "cabin_co2_mmhg": (co2 + co2_event).clip(1.2).round(2),
        "co2_event": co2_event,
        "cabin_temp_c": rng.normal(22.5, 0.6, days).round(1),
        "cabin_humidity_pct": rng.normal(45, 4, days).clip(25, 70).round(0),
        "daily_radiation_msv": dose.round(2),
        "solar_particle_event": spe,
    })


def simulate_astronaut(idx: int, env: pd.DataFrame, k: dict[str, float], rng: np.random.Generator) -> pd.DataFrame:
    days = len(env)
    sex = rng.choice(["M", "F"], p=[0.6, 0.4])
    base = {
        "hr": rng.normal(60, 6), "sys": rng.normal(116, 7), "dia": rng.normal(74, 5),
        "temp": rng.normal(36.6, 0.15), "glu": rng.normal(88, 6), "spo2": rng.normal(97.8, 0.5),
        "sleep": rng.normal(7.0, 0.4), "mood": rng.normal(7.2, 0.6), "stress": rng.normal(3.6, 0.8),
        "rr": rng.normal(14, 1.2), "hrv": rng.normal(62, 12), "exercise": rng.normal(120, 15),
        "mass": rng.normal(80, 8) if sex == "M" else rng.normal(65, 6),
    }
    co2_sensitivity = rng.uniform(0.6, 1.4)
    q3_day, q3_depth = rng.integers(days // 3, int(days * 0.8)), rng.uniform(0.4, 1.2)

    # schedule medical episodes
    intensity = {name: np.zeros(days) for name, _, _ in EPISODES}
    magnitude = {name: np.ones(days) for name, _, _ in EPISODES}
    for name, p, (lo, hi) in EPISODES:
        d = 1
        while d < days:
            if rng.random() < p:
                length = int(rng.integers(lo, hi + 1))
                intensity[name][d:d + length] = episode_profile(length)[: days - d]
                magnitude[name][d:d + length] = rng.uniform(0.8, 1.3)
                d += length + 4
            d += 1

    rows, mood_state, bone, sleep_debt = [], base["mood"], 100.0, 0.0
    ex_hist: list[float] = []
    for d in range(days):
        e = env.iloc[d]
        adapt = 1 - np.exp(-d / 25)                       # microgravity adaptation curve
        early = np.exp(-d / 4)                            # space adaptation syndrome (first days)
        q3 = q3_depth * np.exp(-((d - q3_day) / 20) ** 2)  # third-quarter effect
        I = {n: intensity[n][d] * magnitude[n][d] for n in intensity}
        co2_x = max(0.0, e.cabin_co2_mmhg - 3.5) * co2_sensitivity

        sleep = base["sleep"] - 0.5 * early - 0.7 * q3 - 0.25 * adapt - 0.15 * co2_x \
            - 3.6 * I["sleep_deprivation_low_mood"] - 0.8 * I["fever"] + rng.normal(0, 0.55)
        sleep = float(np.clip(sleep, 1.5, 10))
        sleep_debt = 0.7 * sleep_debt + max(0.0, base["sleep"] - sleep)
        stress = base["stress"] + k["stress_per_sleep_h"] * 0.5 * (sleep - base["sleep"]) + 1.5 * q3 \
            + 0.3 * sleep_debt + 1.0 * e.solar_particle_event + rng.normal(0, 0.7)
        stress = float(np.clip(stress, 1, 10))
        mood_target = base["mood"] - 1.6 * q3 - 0.35 * sleep_debt - 2.6 * I["sleep_deprivation_low_mood"] \
            - 0.8 * I["fever"] - 0.25 * (stress - base["stress"])
        mood_state = float(np.clip(0.6 * mood_state + 0.4 * mood_target + rng.normal(0, 0.45), 1, 10))
        quality = float(np.clip(7 + k["quality_per_sleep_h"] * (sleep - 7) - 0.2 * (stress - 4) + rng.normal(0, 0.6), 1, 10))

        weekday_rest = 0.6 if d % 7 == 6 else 1.0
        exercise = max(0.0, (base["exercise"] * weekday_rest) * (1 - 0.7 * I["fever"]) * (1 - 0.25 * q3) + rng.normal(0, 18))
        ex_hist.append(exercise)
        ex_14 = float(np.mean(ex_hist[-14:]))

        hr = base["hr"] + 4 * adapt + 3 * early + k["hr_per_stress"] * (stress - base["stress"]) \
            + 38 * I["tachycardia"] + 11 * I["fever"] + 3 * I["hypertension"] + 2.5 * co2_x + rng.normal(0, 2.6)
        hrv = base["hrv"] - 6 * adapt - 3.5 * (stress - base["stress"]) - 20 * I["tachycardia"] - 12 * I["fever"] + rng.normal(0, 5)
        rr = base["rr"] + 3.0 * I["fever"] + 1.6 * co2_x + 2 * I["tachycardia"] + rng.normal(0, 0.9)
        sys = base["sys"] - 3 * adapt + 0.8 * (stress - base["stress"]) + 36 * I["hypertension"] + rng.normal(0, 4.5)
        dia = base["dia"] - 2 * adapt + 0.5 * (stress - base["stress"]) + 19 * I["hypertension"] + rng.normal(0, 3.2)
        temp = base["temp"] + 0.12 * adapt + 1.7 * I["fever"] + 0.03 * (e.cabin_temp_c - 22.5) + rng.normal(0, 0.12)
        glu = base["glu"] + 75 * I["hyperglycemia"] + 1.2 * (stress - base["stress"]) + rng.normal(0, 5.5)
        spo2 = base["spo2"] - 1.6 * co2_x - 0.6 * I["fever"] + rng.normal(0, 0.4)
        mass = base["mass"] * (1 - 0.025 * adapt) - 0.6 * I["fever"] + rng.normal(0, 0.25)
        bone -= 0.045 * float(np.clip(1.6 - ex_14 / 150, 0.5, 1.6)) * rng.normal(1, 0.08)

        label = "normal"
        strongest = max(I, key=I.get)
        if I[strongest] >= LABEL_INTENSITY:
            label = strongest
        elif e.co2_event > 0 and (co2_x >= 1.2 or spo2 < 94.5):
            label = "hypoxia_co2"

        rows.append({
            "astronaut_id": f"A{idx:02d}", "sex": sex, "mission_day": d + 1,
            "heart_rate_bpm": round(hr, 1), "hrv_ms": round(max(hrv, 8), 1), "resp_rate_bpm": round(max(rr, 6), 1),
            "systolic_bp": round(sys), "diastolic_bp": round(dia), "body_temp_c": round(temp, 2),
            "blood_glucose_mgdl": round(glu), "spo2_pct": round(min(spo2, 100), 1),
            "sleep_hours": round(sleep, 1), "sleep_quality": round(quality, 1),
            "mood_score": round(mood_state, 1), "stress_level": round(stress, 1),
            "exercise_min": round(exercise), "body_mass_kg": round(mass, 1),
            "bone_density_pct_baseline": round(bone + rng.normal(0, 0.05), 2),
            "anomaly_label": int(label != "normal"), "anomaly_type": label,
        })
    out = pd.DataFrame(rows).merge(env.drop(columns="co2_event"), on="mission_day")
    out["cum_radiation_msv"] = out["daily_radiation_msv"].cumsum().round(2)
    out.insert(1, "age", int(rng.integers(32, 56)))
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--crew", type=int, default=24)
    ap.add_argument("--days", type=int, default=180)
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    k = calibrate_couplings()
    # crews of 4 share one mission environment
    frames, env = [], None
    for i in range(args.crew):
        if i % 4 == 0:
            env = simulate_environment(args.days, rng)
        frames.append(simulate_astronaut(i + 1, env, k, rng))
    df = pd.concat(frames, ignore_index=True)
    cols = [c for c in df.columns if c not in ("anomaly_label", "anomaly_type")] + ["anomaly_label", "anomaly_type"]
    df[cols].to_csv(OUTPUT, index=False)
    print(f"couplings: { {a: round(b, 2) for a, b in k.items()} }")
    print(f"wrote {OUTPUT.relative_to(ROOT)}  shape={df.shape}  anomaly_rate={df.anomaly_label.mean():.3f}")
    print(df.anomaly_type.value_counts().to_string())


if __name__ == "__main__":
    main()
