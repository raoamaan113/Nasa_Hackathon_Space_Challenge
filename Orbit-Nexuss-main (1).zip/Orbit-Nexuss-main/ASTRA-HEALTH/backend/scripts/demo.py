"""Live demo scenario for judges. Start the server first, then:  python scripts/demo.py [base_url]

Story: a healthy astronaut develops a fever over three days; a cabin CO2 problem follows;
the system warns early, explains, and the assistant answers a question.
"""
import sys

import httpx

BASE = (sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000") + "/api/v1"
NORMAL = dict(heart_rate_bpm=62, hrv_ms=60, resp_rate_bpm=14, systolic_bp=116, diastolic_bp=74, body_temp_c=36.6,
              blood_glucose_mgdl=88, spo2_pct=98, sleep_hours=7.2, sleep_quality=7.5, mood_score=7, stress_level=3.5,
              exercise_min=120, body_mass_kg=70, bone_density_pct_baseline=99.6, cabin_co2_mmhg=2.6, cabin_temp_c=22.5,
              cabin_humidity_pct=45, daily_radiation_msv=0.6)
STORY = [
    ("Day 9: slightly off (prodrome)", dict(body_temp_c=37.2, heart_rate_bpm=67, sleep_hours=6.4, exercise_min=95)),
    ("Day 10: fever building", dict(body_temp_c=37.9, heart_rate_bpm=72, resp_rate_bpm=16, sleep_hours=6.0, exercise_min=60)),
    ("Day 11: fever peak", dict(body_temp_c=38.9, heart_rate_bpm=78, resp_rate_bpm=18, sleep_hours=5.6, mood_score=5, exercise_min=20)),
    ("Day 12: recovered, but cabin CO2 rises", dict(cabin_co2_mmhg=6.8, spo2_pct=92.5, resp_rate_bpm=18.5, heart_rate_bpm=69)),
    ("Day 13: solar particle event", dict(daily_radiation_msv=12.5, stress_level=6.5)),
]

with httpx.Client(timeout=60, trust_env=False) as c:
    who = c.post(f"{BASE}/astronauts", json={"name": "Demo Astronaut", "age": 41, "sex": "F"}).json()
    aid = who["id"]
    print(f"Created {aid}. Logging 8 normal days to learn the personal baseline...")
    for _ in range(8):
        c.post(f"{BASE}/readings", json={"astronaut_id": aid, **NORMAL}).raise_for_status()
    for title, change in STORY:
        r = c.post(f"{BASE}/readings", json={"astronaut_id": aid, **NORMAL, **change}).json()
        a = r["assessment"]
        print(f"\n=== {title} ===\n  status: {r['overall_level'].upper()}   ML risk: {a['risk_score']}/100   pattern: {a['predicted_condition']}")
        for al in r["alerts"]:
            print(f"  [{al['level']:5}] {al['message']}")
    print("\n=== Five hazards ===")
    for h in c.get(f"{BASE}/astronauts/{aid}/hazards").json():
        print(f"  {h['hazard']:28} {h['status']:8} {h['summary']}")
    print("\n=== Reminders ===")
    for rem in c.get(f"{BASE}/astronauts/{aid}/reminders").json()[:5]:
        print(f"  ({rem['priority']}) {rem['title']}")
    chat = c.post(f"{BASE}/assistant/chat", json={"astronaut_id": aid, "message": "Give me a summary of my last few days and what I should do today."}).json()
    print(f"\n=== Assistant ({chat['source']}{', ' + chat['model'] if chat['model'] else ''}) ===\n{chat['reply']}")
