"""Verify the Groq key and model list from YOUR machine:  python scripts/check_llm.py"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.services.llm import LLMService  # noqa: E402

llm = LLMService()
if not llm.configured:
    sys.exit("GROQ_API_KEY is missing - add it to .env")
try:
    live = llm.available_models()
except Exception as exc:  # noqa: BLE001
    sys.exit(f"Could not reach Groq: {exc}")
print("Key works. Live models:", ", ".join(live))
usable = [m for m in llm.models if m in live]
print("Configured models that are live:", usable or "NONE - set GROQ_MODELS in .env to one of the live models above")
res = llm.complete([{"role": "user", "content": "Reply with exactly: link OK"}], max_tokens=200)
print("Test completion:", res if res else "FAILED (see warning above)")
