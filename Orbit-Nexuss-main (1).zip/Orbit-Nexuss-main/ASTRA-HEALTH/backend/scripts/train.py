"""Train the ML engine and write models/engine.joblib + models/metrics.json."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.config import settings  # noqa: E402
from app.ml.engine import train_and_save  # noqa: E402

if __name__ == "__main__":
    engine = train_and_save(settings.data_csv, settings.model_path, settings.metrics_path)
    print(json.dumps(engine.metrics, indent=2))
