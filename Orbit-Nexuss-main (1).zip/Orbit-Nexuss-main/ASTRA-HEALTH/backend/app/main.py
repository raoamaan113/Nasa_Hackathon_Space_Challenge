"""FastAPI entry point.  Run:  uvicorn app.main:app --reload"""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import router
from app.config import ROOT, settings
from app.database import Database
from app.ml.engine import HealthEngine, train_and_save
from app.services.llm import LLMService
from app.services.monitor import HealthMonitor

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("astrohealth")


def load_engine() -> HealthEngine:
    if settings.model_path.exists():
        try:
            return HealthEngine.load(settings.model_path)
        except Exception as exc:  # noqa: BLE001 - e.g. a different scikit-learn version
            log.warning("saved model could not be loaded (%s) - retraining", exc)
    log.info("training the ML engine now (about 15 s)")
    return train_and_save(settings.data_csv, settings.model_path, settings.metrics_path)


def create_app(db_path: Path | str | None = None, llm: LLMService | None = None,
               engine: HealthEngine | None = None, seed: bool = True) -> FastAPI:
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        db = Database(db_path or settings.db_path)
        monitor = HealthMonitor(db, engine or load_engine(), llm or LLMService())
        if seed:
            monitor.seed_demo_crew()
            monitor.seed_telemetry_stream()
        app.state.monitor = monitor
        yield
        db.close()

    app = FastAPI(title=settings.app_name, version=settings.version, lifespan=lifespan,
                  description="Health monitoring backend for astronauts: logging, ML risk assessment, "
                              "colour-coded alerts, five-hazard dashboard and an LLM assistant. "
                              "Decision support only - not a medical diagnosis.")
    app.add_middleware(CORSMiddleware, allow_origins=list(settings.cors_origins), allow_methods=["*"], allow_headers=["*"])
    app.include_router(router)

    @app.get("/health", tags=["meta"])
    def health():
        return {"status": "ok", "version": settings.version, "model_loaded": app.state.monitor.engine.clf is not None,
                "llm_configured": app.state.monitor.llm.configured}

    # ---- web UI: the built React app (backend/static) is served by this same process
    static = ROOT / "static"
    if (static / "index.html").exists():
        app.mount("/assets", StaticFiles(directory=static / "assets"), name="assets")

        @app.get("/{path:path}", include_in_schema=False)
        def spa(path: str):
            if path.startswith(("api/", "docs", "openapi", "redoc")):
                raise HTTPException(404, "not found")
            file = (static / path).resolve()
            if path and file.is_file() and static.resolve() in file.parents:
                return FileResponse(file)
            return FileResponse(static / "index.html")   # client-side routes

    return app


app = create_app()
