"""Health-risk ML engine.

Two complementary models, both driven by personal-baseline features:

1. IsolationForest (unsupervised) -> "how unusual is today for THIS astronaut?"
   Works for conditions never seen in training.
2. HistGradientBoostingClassifier (supervised) -> which known condition pattern
   it resembles (fever, tachycardia, hypoxia/CO2, ...), with probabilities.

The two are blended into a 0-100 risk score. This is decision support, not diagnosis.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.ensemble import HistGradientBoostingClassifier, IsolationForest
from sklearn.metrics import average_precision_score, classification_report, roc_auc_score
from sklearn.model_selection import GroupShuffleSplit

from app.ml.features import FEATURE_COLS, VITAL_COLS, Z_COLS, build_features

NORMAL = "normal"
AMBER_AT, RED_AT = 35, 65


@dataclass
class Assessment:
    risk_score: int
    risk_level: str                 # green | amber | red
    predicted_condition: str
    condition_probabilities: dict[str, float]
    novelty_score: float            # 0..1 isolation-forest unusualness
    top_deviations: list[dict]      # vitals furthest from personal baseline

    def to_dict(self) -> dict:
        return self.__dict__.copy()


class HealthEngine:
    def __init__(self) -> None:
        self.clf: HistGradientBoostingClassifier | None = None
        self.iso: IsolationForest | None = None
        self.iso_lo = 0.0
        self.iso_hi = 1.0
        self.metrics: dict = {}

    # ------------------------------------------------------------------ training
    @staticmethod
    def _new_clf() -> HistGradientBoostingClassifier:
        return HistGradientBoostingClassifier(
            max_iter=250, learning_rate=0.07, max_depth=6, l2_regularization=0.5,
            class_weight="balanced", random_state=42,
        )

    @staticmethod
    def _new_iso() -> IsolationForest:
        return IsolationForest(n_estimators=300, contamination="auto", random_state=42)

    def train(self, df: pd.DataFrame, evaluate: bool = True) -> dict:
        feats = build_features(df)
        y = df.sort_values(["astronaut_id", "mission_day"])["anomaly_type"].to_numpy()
        groups = feats["astronaut_id"].to_numpy()
        X = feats[FEATURE_COLS]

        if evaluate:  # hold out whole astronauts -> honest generalisation to unseen crew
            tr, te = next(GroupShuffleSplit(n_splits=1, test_size=0.25, random_state=0).split(X, y, groups))
            clf = self._new_clf().fit(X.iloc[tr], y[tr])
            iso = self._new_iso().fit(X.iloc[tr][Z_COLS])
            proba = clf.predict_proba(X.iloc[te])
            p_anom = 1 - proba[:, list(clf.classes_).index(NORMAL)]
            y_bin = (y[te] != NORMAL).astype(int)
            iso_score = -iso.score_samples(X.iloc[te][Z_COLS])
            report = classification_report(y[te], clf.predict(X.iloc[te]), output_dict=True, zero_division=0)
            self.metrics = {
                "evaluation": "25% of astronauts held out entirely (GroupShuffleSplit)",
                "test_astronauts": sorted(set(groups[te])),
                "n_train_rows": int(len(tr)), "n_test_rows": int(len(te)),
                "classifier": {
                    "anomaly_roc_auc": round(float(roc_auc_score(y_bin, p_anom)), 4),
                    "anomaly_pr_auc": round(float(average_precision_score(y_bin, p_anom)), 4),
                    "macro_f1": round(report["macro avg"]["f1-score"], 4),
                    "accuracy": round(report["accuracy"], 4),
                    "per_class": {k: {m: round(v[m], 3) for m in ("precision", "recall", "f1-score")} | {"support": int(v["support"])}
                                  for k, v in report.items() if isinstance(v, dict) and "avg" not in k},
                },
                "isolation_forest": {
                    "anomaly_roc_auc": round(float(roc_auc_score(y_bin, iso_score)), 4),
                    "anomaly_pr_auc": round(float(average_precision_score(y_bin, iso_score)), 4),
                    "note": "unsupervised - never sees labels",
                },
                "caveat": "Measured on synthetic data; not a clinical accuracy claim.",
            }

        # final fit on everything
        self.clf = self._new_clf().fit(X, y)
        self.iso = self._new_iso().fit(X[Z_COLS])
        raw = -self.iso.score_samples(X[Z_COLS])
        self.iso_lo, self.iso_hi = float(np.percentile(raw, 50)), float(np.percentile(raw, 99.5))
        return self.metrics

    # --------------------------------------------------------------- persistence
    def save(self, model_path: Path, metrics_path: Path | None = None) -> None:
        model_path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump({"clf": self.clf, "iso": self.iso, "iso_lo": self.iso_lo, "iso_hi": self.iso_hi,
                     "metrics": self.metrics, "sklearn_version": sklearn.__version__}, model_path)
        if metrics_path:
            metrics_path.write_text(json.dumps(self.metrics, indent=2))

    @classmethod
    def load(cls, model_path: Path) -> "HealthEngine":
        bundle = joblib.load(model_path)
        if bundle.get("sklearn_version") != sklearn.__version__:
            raise RuntimeError(f"model was trained with scikit-learn {bundle.get('sklearn_version')}, "
                               f"this machine has {sklearn.__version__}")
        eng = cls()
        eng.clf, eng.iso = bundle["clf"], bundle["iso"]
        eng.iso_lo, eng.iso_hi, eng.metrics = bundle["iso_lo"], bundle["iso_hi"], bundle["metrics"]
        return eng

    # ------------------------------------------------------------------- scoring
    def score_frame(self, df: pd.DataFrame) -> list[Assessment]:
        """Score every row of a history frame (one or many astronauts), in sorted order."""
        if self.clf is None or self.iso is None:
            raise RuntimeError("engine is not trained")
        feats = build_features(df)
        proba = self.clf.predict_proba(feats[FEATURE_COLS])
        classes = list(self.clf.classes_)
        normal_idx = classes.index(NORMAL)
        raw = -self.iso.score_samples(feats[Z_COLS])
        novelty = np.clip((raw - self.iso_lo) / (self.iso_hi - self.iso_lo), 0, 1)
        z = feats[Z_COLS].to_numpy()

        results = []
        for i in range(len(feats)):
            p_anom = float(1 - proba[i, normal_idx])
            risk = int(round(100 * max(p_anom, 0.75 * p_anom + 0.25 * novelty[i], 0.6 * novelty[i])))
            level = "red" if risk >= RED_AT else "amber" if risk >= AMBER_AT else "green"
            order = np.argsort(-np.abs(z[i]))[:3]
            top = [{"vital": VITAL_COLS[j], "value": _num(feats.iloc[i][VITAL_COLS[j]]),
                    "personal_baseline": _num(feats.iloc[i][f"{VITAL_COLS[j]}_base"]),
                    "z_score": round(float(z[i, j]), 2)} for j in order if abs(z[i, j]) >= 1.5]
            results.append(Assessment(
                risk_score=risk, risk_level=level,
                predicted_condition=classes[int(np.argmax(proba[i]))] if level != "green" or p_anom >= 0.5 else NORMAL,
                condition_probabilities={c: round(float(p), 3) for c, p in zip(classes, proba[i]) if p >= 0.01},
                novelty_score=round(float(novelty[i]), 3), top_deviations=top,
            ))
        return results

    def score_latest(self, history: pd.DataFrame) -> Assessment:
        """Score the most recent day of ONE astronaut's history."""
        tail = history.sort_values("mission_day").tail(20)
        return self.score_frame(tail)[-1]


def _num(x) -> float | None:
    return None if pd.isna(x) else round(float(x), 2)


def train_and_save(csv_path: Path, model_path: Path, metrics_path: Path) -> HealthEngine:
    eng = HealthEngine()
    eng.train(pd.read_csv(csv_path))
    eng.save(model_path, metrics_path)
    return eng
