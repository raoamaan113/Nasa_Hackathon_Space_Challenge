"""Feature engineering shared by training and serving.

Every vital is compared with the astronaut's OWN recent baseline (robust rolling
median over the previous 14 days). A heart rate of 90 bpm is unremarkable for one
person and a 30-bpm jump for another, so personal z-scores are the key signal.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

BASELINE_WINDOW = 14
MIN_HISTORY = 5

# vital -> (population mean, typical day-to-day std). Used as the fallback baseline
# before an astronaut has MIN_HISTORY days of data, and as a floor for the std.
VITALS: dict[str, tuple[float, float]] = {
    "heart_rate_bpm": (65.0, 3.5),
    "hrv_ms": (52.0, 7.0),
    "resp_rate_bpm": (14.0, 1.1),
    "systolic_bp": (116.0, 5.0),
    "diastolic_bp": (74.0, 3.5),
    "body_temp_c": (36.7, 0.15),
    "blood_glucose_mgdl": (89.0, 6.0),
    "spo2_pct": (97.7, 0.5),
    "sleep_hours": (6.7, 0.7),
    "sleep_quality": (6.5, 0.9),
    "mood_score": (6.5, 0.8),
    "stress_level": (4.2, 0.9),
    "exercise_min": (110.0, 25.0),
    "cabin_co2_mmhg": (2.7, 0.35),
}
VITAL_COLS = list(VITALS)
Z_COLS = [f"{v}_z" for v in VITAL_COLS]
DELTA_COLS = [f"{v}_d1" for v in VITAL_COLS]
FEATURE_COLS = VITAL_COLS + Z_COLS + DELTA_COLS


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    """Return FEATURE_COLS (+ personal baselines as ``<vital>_base``) for every row.

    ``df`` must contain ``astronaut_id``, ``mission_day`` and the vital columns
    (missing vitals are allowed and stay NaN / neutral).
    """
    df = df.sort_values(["astronaut_id", "mission_day"]).copy()
    for v in VITAL_COLS:
        if v not in df:
            df[v] = np.nan
    df[VITAL_COLS] = df[VITAL_COLS].astype(float)
    grouped = df.groupby("astronaut_id", sort=False)
    out = df[["astronaut_id", "mission_day"] + VITAL_COLS].copy()
    for v, (pop_mean, std_floor) in VITALS.items():
        prev = grouped[v].shift(1)
        roll = prev.groupby(df["astronaut_id"], sort=False).rolling(BASELINE_WINDOW, min_periods=MIN_HISTORY)
        base = roll.median().reset_index(level=0, drop=True).fillna(pop_mean)
        std = roll.std().reset_index(level=0, drop=True).fillna(std_floor).clip(lower=std_floor)
        out[f"{v}_base"] = base
        out[f"{v}_z"] = ((df[v] - base) / std).clip(-12, 12)
        out[f"{v}_d1"] = df[v] - prev
    out[Z_COLS + DELTA_COLS] = out[Z_COLS + DELTA_COLS].fillna(0.0)
    return out
