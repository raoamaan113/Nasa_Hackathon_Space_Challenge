"""Pydantic request / response models."""
from __future__ import annotations

from datetime import datetime
from typing import Literal, Optional

from pydantic import BaseModel, Field

Level = Literal["green", "amber", "red"]


class AstronautIn(BaseModel):
    id: Optional[str] = Field(None, description="Optional custom id, e.g. 'A25'", max_length=20)
    name: str = Field(..., min_length=1, max_length=80)
    age: int = Field(..., ge=18, le=80)
    sex: Literal["M", "F"]


class Astronaut(BaseModel):
    id: str
    name: str
    age: Optional[int] = None
    sex: Optional[str] = None
    mission_start: Optional[str] = None
    mission_day: int = 0
    logging_streak_days: int = 0


class ReadingIn(BaseModel):
    """One daily health log. Every measurement is optional - log what you have."""
    astronaut_id: str
    mission_day: Optional[int] = Field(None, ge=1, description="Defaults to the next day after the last log")
    heart_rate_bpm: Optional[float] = Field(None, ge=20, le=250)
    hrv_ms: Optional[float] = Field(None, ge=1, le=300)
    resp_rate_bpm: Optional[float] = Field(None, ge=4, le=60)
    systolic_bp: Optional[float] = Field(None, ge=50, le=260)
    diastolic_bp: Optional[float] = Field(None, ge=30, le=160)
    body_temp_c: Optional[float] = Field(None, ge=30, le=43)
    blood_glucose_mgdl: Optional[float] = Field(None, ge=20, le=600)
    spo2_pct: Optional[float] = Field(None, ge=50, le=100)
    sleep_hours: Optional[float] = Field(None, ge=0, le=24)
    sleep_quality: Optional[float] = Field(None, ge=1, le=10)
    mood_score: Optional[float] = Field(None, ge=1, le=10)
    stress_level: Optional[float] = Field(None, ge=1, le=10)
    exercise_min: Optional[float] = Field(None, ge=0, le=600)
    body_mass_kg: Optional[float] = Field(None, ge=30, le=200)
    bone_density_pct_baseline: Optional[float] = Field(None, ge=50, le=110)
    cabin_co2_mmhg: Optional[float] = Field(None, ge=0, le=40)
    cabin_temp_c: Optional[float] = Field(None, ge=0, le=45)
    cabin_humidity_pct: Optional[float] = Field(None, ge=0, le=100)
    daily_radiation_msv: Optional[float] = Field(None, ge=0, le=1000)
    notes: Optional[str] = Field(None, max_length=500)


class Alert(BaseModel):
    source: Literal["threshold", "ml"]
    level: Level
    metric: str
    value: Optional[float] = None
    message: str
    guidance: str


class SymptomIn(BaseModel):
    astronaut_id: str
    body_part: str = Field(..., min_length=1, max_length=40, examples=["head", "lower_back", "left_knee"])
    severity: int = Field(..., ge=1, le=10)
    description: str = Field("", max_length=500)
    mission_day: Optional[int] = Field(None, ge=1)


class ChatTurn(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(..., max_length=4000)


class ChatIn(BaseModel):
    astronaut_id: str
    message: str = Field(..., min_length=1, max_length=2000)
    history: list[ChatTurn] = Field(default_factory=list, max_length=12)


class ChatOut(BaseModel):
    reply: str
    source: Literal["llm", "offline"]
    model: Optional[str] = None
    disclaimer: str = "Decision support only - not a medical diagnosis. Contact the flight surgeon for any red alert."


class TelemetrySample(BaseModel):
    """One sensor/wearable sample. Samples are averaged into the daily record automatically."""
    astronaut_id: str
    timestamp: Optional[datetime] = Field(None, description="Defaults to now (UTC)")
    heart_rate_bpm: Optional[float] = Field(None, ge=20, le=250)
    resp_rate_bpm: Optional[float] = Field(None, ge=4, le=60)
    systolic_bp: Optional[float] = Field(None, ge=50, le=260)
    diastolic_bp: Optional[float] = Field(None, ge=30, le=160)
    body_temp_c: Optional[float] = Field(None, ge=30, le=43)
    spo2_pct: Optional[float] = Field(None, ge=50, le=100)
    sleep_quality: Optional[float] = Field(None, ge=1, le=10)
    mood_score: Optional[float] = Field(None, ge=1, le=10)
    daily_radiation_msv: Optional[float] = Field(None, ge=0, le=1000, description="Dose rate in mSv/day")
    cabin_co2_mmhg: Optional[float] = Field(None, ge=0, le=40)


class TelemetryBatch(BaseModel):
    samples: list[TelemetrySample] = Field(..., min_length=1, max_length=1000)


WELLBEING_ITEMS = {
    "low_mood": "Felt down or low in mood",
    "poor_sleep": "Slept badly or woke unrested",
    "stress_overload": "Felt overloaded or under pressure",
    "feeling_isolated": "Felt cut off from crew, family or Earth",
    "trouble_focusing": "Had trouble concentrating on tasks",
}


class WellbeingIn(BaseModel):
    """Short crew check-in. Each item: 0 = not at all, 1 = some days, 2 = most days, 3 = every day (last 7 days)."""
    astronaut_id: str
    low_mood: int = Field(..., ge=0, le=3)
    poor_sleep: int = Field(..., ge=0, le=3)
    stress_overload: int = Field(..., ge=0, le=3)
    feeling_isolated: int = Field(..., ge=0, le=3)
    trouble_focusing: int = Field(..., ge=0, le=3)
