"""REST API (v1)."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import PlainTextResponse

from app.schemas import (WELLBEING_ITEMS, Astronaut, AstronautIn, ChatIn, ChatOut, ReadingIn, SymptomIn,
                         TelemetryBatch, WellbeingIn)
from app.services import reference
from app.services.monitor import HealthMonitor, NotFound

router = APIRouter(prefix="/api/v1")


def svc(request: Request) -> HealthMonitor:
    return request.app.state.monitor


def _guard(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except NotFound as exc:
        raise HTTPException(404, str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc


# ------------------------------------------------------------------ astronauts
@router.get("/astronauts", response_model=list[Astronaut], tags=["astronauts"])
def list_astronauts(m: HealthMonitor = Depends(svc)):
    return m.list_astronauts()


@router.post("/astronauts", response_model=Astronaut, status_code=201, tags=["astronauts"])
def create_astronaut(body: AstronautIn, m: HealthMonitor = Depends(svc)):
    return _guard(m.create_astronaut, body.name, body.age, body.sex, body.id)


@router.get("/astronauts/{astronaut_id}/dashboard", tags=["dashboard"],
            summary="Everything the home screen needs in one call")
def dashboard(astronaut_id: str, m: HealthMonitor = Depends(svc)):
    return _guard(m.dashboard, astronaut_id)


@router.get("/astronauts/{astronaut_id}/readings", tags=["readings"])
def readings(astronaut_id: str, days: int = Query(30, ge=1, le=1000), m: HealthMonitor = Depends(svc)):
    return _guard(m.readings, astronaut_id, days)


@router.get("/astronauts/{astronaut_id}/series/{metric}", tags=["readings"], summary="Chart-ready time series")
def series(astronaut_id: str, metric: str, days: int = Query(30, ge=1, le=1000), m: HealthMonitor = Depends(svc)):
    return _guard(m.series, astronaut_id, metric, days)


@router.get("/astronauts/{astronaut_id}/alerts", response_model=list[dict], tags=["dashboard"])
def alerts(astronaut_id: str, days: int = Query(7, ge=1, le=90), m: HealthMonitor = Depends(svc)):
    return _guard(m.alerts, astronaut_id, days)


@router.get("/astronauts/{astronaut_id}/hazards", tags=["dashboard"], summary="NASA's five spaceflight hazards")
def hazards(astronaut_id: str, m: HealthMonitor = Depends(svc)):
    return _guard(m.hazards, astronaut_id)


@router.get("/astronauts/{astronaut_id}/forecast", tags=["dashboard"])
def forecast(astronaut_id: str, m: HealthMonitor = Depends(svc)):
    return _guard(m.forecast, astronaut_id)


@router.get("/astronauts/{astronaut_id}/symptoms", tags=["symptoms"])
def list_symptoms(astronaut_id: str, m: HealthMonitor = Depends(svc)):
    return _guard(m.symptoms, astronaut_id)


@router.get("/astronauts/{astronaut_id}/summary", response_model=ChatOut, tags=["assistant"],
            summary="LLM daily health briefing (offline fallback built in)")
def summary(astronaut_id: str, m: HealthMonitor = Depends(svc)):
    return _guard(m.daily_summary, astronaut_id)


# --------------------------------------------------------------------- logging
@router.post("/readings", status_code=201, tags=["readings"],
             summary="Log a daily reading -> instant ML assessment + colour-coded alerts")
def log_reading(body: ReadingIn, m: HealthMonitor = Depends(svc)):
    return _guard(m.log_reading, body.model_dump())


@router.post("/symptoms", status_code=201, tags=["symptoms"], summary="Body-map symptom entry")
def add_symptom(body: SymptomIn, m: HealthMonitor = Depends(svc)):
    return _guard(m.add_symptom, body.model_dump())


@router.post("/assistant/chat", response_model=ChatOut, tags=["assistant"])
def chat(body: ChatIn, m: HealthMonitor = Depends(svc)):
    return _guard(m.chat, body.astronaut_id, body.message, [t.model_dump() for t in body.history])


@router.post("/telemetry", status_code=201, tags=["telemetry"],
             summary="Ingest wearable/sensor samples -> rolled up into the daily record and re-scored")
def ingest_telemetry(body: TelemetryBatch, m: HealthMonitor = Depends(svc)):
    return _guard(m.ingest_telemetry, [s.model_dump() for s in body.samples])


@router.get("/astronauts/{astronaut_id}/telemetry", tags=["telemetry"], summary="Raw sensor samples (latest N)")
def telemetry(astronaut_id: str, limit: int = Query(48, ge=1, le=5000), m: HealthMonitor = Depends(svc)):
    return _guard(m.telemetry, astronaut_id, limit)


@router.post("/wellbeing", status_code=201, tags=["wellbeing"], summary="Weekly 5-question well-being check-in")
def add_wellbeing(body: WellbeingIn, m: HealthMonitor = Depends(svc)):
    return _guard(m.add_wellbeing, body.model_dump())


@router.get("/wellbeing/questions", tags=["wellbeing"])
def wellbeing_questions():
    return {"scale": {"0": "Not at all", "1": "Some days", "2": "Most days", "3": "Every day"},
            "period": "last 7 days", "items": WELLBEING_ITEMS}


@router.get("/astronauts/{astronaut_id}/wellbeing", tags=["wellbeing"])
def list_wellbeing(astronaut_id: str, m: HealthMonitor = Depends(svc)):
    return _guard(m.wellbeing, astronaut_id)


@router.get("/astronauts/{astronaut_id}/reminders", tags=["dashboard"], summary="Reminders and notifications")
def reminders(astronaut_id: str, m: HealthMonitor = Depends(svc)):
    return _guard(m.reminders, astronaut_id)


@router.get("/astronauts/{astronaut_id}/export", tags=["records"], summary="Full health record (JSON or CSV)")
def export(astronaut_id: str, format: str = Query("json", pattern="^(json|csv)$"), m: HealthMonitor = Depends(svc)):
    if format == "csv":
        return PlainTextResponse(_guard(m.export_csv, astronaut_id), media_type="text/csv",
                                 headers={"Content-Disposition": f'attachment; filename="{astronaut_id}_health_record.csv"'})
    return _guard(m.export_record, astronaut_id)


@router.get("/crew/overview", tags=["dashboard"], summary="Whole-crew status, most urgent first")
def crew_overview(m: HealthMonitor = Depends(svc)):
    return m.crew_overview()


@router.get("/reference/standards", tags=["reference"], summary="Mission warning bands used for alerts")
def standards():
    return reference.STANDARDS


@router.get("/reference/nasa-study", tags=["reference"], summary="Bundled NASA OSDR study (scientific context)")
def nasa_study():
    return reference.nasa_study()


# ------------------------------------------------------------------------ meta
@router.get("/ml/metrics", tags=["meta"])
def ml_metrics(m: HealthMonitor = Depends(svc)):
    return m.engine.metrics


@router.get("/assistant/status", tags=["meta"], summary="Is the LLM reachable, and which models are live?")
def assistant_status(m: HealthMonitor = Depends(svc)):
    status = {"configured": m.llm.configured, "preferred_models": m.llm.models, "reachable": False, "live_models": []}
    if m.llm.configured:
        try:
            status["live_models"] = m.llm.available_models()
            status["reachable"] = True
        except Exception as exc:  # noqa: BLE001 - report any connectivity problem
            status["error"] = str(exc)[:200]
    return status


