"""Central configuration, loaded from environment variables / .env."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env")


@dataclass(frozen=True)
class Settings:
    app_name: str = "ASTRA-HEALTH API"
    version: str = "1.1.0"
    data_csv: Path = ROOT / "data" / "astronaut_health.csv"
    model_path: Path = ROOT / "models" / "engine.joblib"
    metrics_path: Path = ROOT / "models" / "metrics.json"
    standards_csv: Path = ROOT / "data" / "external" / "documentation" / "astronaut_baseline_standards.csv"
    telemetry_csv: Path = ROOT / "data" / "external" / "simulated" / "astronaut_telemetry_stream.csv"
    nasa_study_json: Path = ROOT / "data" / "external" / "nasa" / "OSD-665_metadata.json"
    db_path: Path = Path(os.getenv("DB_PATH", ROOT / "data" / "astrohealth.db"))
    seed_crew: int = int(os.getenv("SEED_CREW", "4"))          # demo astronauts loaded on first start
    mission_length_days: int = int(os.getenv("MISSION_LENGTH_DAYS", "180"))
    career_radiation_limit_msv: float = 600.0                   # NASA-STD-3001 career limit
    groq_api_key: str = os.getenv("GROQ_API_KEY", "")
    groq_base_url: str = os.getenv("GROQ_BASE_URL", "https://api.groq.com/openai/v1")
    groq_models: tuple[str, ...] = field(default_factory=lambda: tuple(
        m.strip() for m in os.getenv("GROQ_MODELS", "openai/gpt-oss-120b,openai/gpt-oss-20b").split(",") if m.strip()
    ))
    llm_timeout_s: float = float(os.getenv("LLM_TIMEOUT_S", "25"))
    cors_origins: tuple[str, ...] = tuple(os.getenv("CORS_ORIGINS", "*").split(","))


settings = Settings()
