"""SQLite persistence (local-first: the app keeps working with no ground link)."""
from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

import pandas as pd

READING_COLS = [
    "heart_rate_bpm", "hrv_ms", "resp_rate_bpm", "systolic_bp", "diastolic_bp", "body_temp_c",
    "blood_glucose_mgdl", "spo2_pct", "sleep_hours", "sleep_quality", "mood_score", "stress_level",
    "exercise_min", "body_mass_kg", "bone_density_pct_baseline", "cabin_co2_mmhg", "cabin_temp_c",
    "cabin_humidity_pct", "daily_radiation_msv", "cum_radiation_msv",
]
TELEMETRY_COLS = ["heart_rate_bpm", "resp_rate_bpm", "systolic_bp", "diastolic_bp", "body_temp_c", "spo2_pct",
                  "sleep_quality", "mood_score", "daily_radiation_msv", "cabin_co2_mmhg"]
_ML_COLS = ["risk_score", "risk_level", "predicted_condition", "assessment_json"]

_SCHEMA = f"""
CREATE TABLE IF NOT EXISTS astronauts (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, age INTEGER, sex TEXT, mission_start TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS readings (
    astronaut_id TEXT NOT NULL REFERENCES astronauts(id), mission_day INTEGER NOT NULL,
    {", ".join(c + " REAL" for c in READING_COLS)},
    notes TEXT, risk_score INTEGER, risk_level TEXT, predicted_condition TEXT, assessment_json TEXT,
    logged_at TEXT DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (astronaut_id, mission_day));
CREATE TABLE IF NOT EXISTS symptoms (
    id INTEGER PRIMARY KEY AUTOINCREMENT, astronaut_id TEXT NOT NULL REFERENCES astronauts(id),
    mission_day INTEGER, body_part TEXT NOT NULL, severity INTEGER NOT NULL, description TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS telemetry (
    astronaut_id TEXT NOT NULL REFERENCES astronauts(id), ts TEXT NOT NULL,
    {", ".join(c + " REAL" for c in TELEMETRY_COLS)},
    PRIMARY KEY (astronaut_id, ts));
CREATE TABLE IF NOT EXISTS wellbeing (
    id INTEGER PRIMARY KEY AUTOINCREMENT, astronaut_id TEXT NOT NULL REFERENCES astronauts(id),
    mission_day INTEGER, answers_json TEXT NOT NULL, score INTEGER NOT NULL, level TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP);
"""


class Database:
    def __init__(self, path: Path | str) -> None:
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON")
        self._conn.executescript(_SCHEMA)

    @contextmanager
    def _tx(self) -> Iterator[sqlite3.Connection]:
        with self._lock:
            try:
                yield self._conn
                self._conn.commit()
            except Exception:
                self._conn.rollback()
                raise

    def close(self) -> None:
        self._conn.close()

    # ---------------------------------------------------------------- astronauts
    def add_astronaut(self, id_: str, name: str, age: int | None, sex: str | None) -> None:
        with self._tx() as c:
            c.execute("INSERT INTO astronauts (id, name, age, sex) VALUES (?,?,?,?)", (id_, name, age, sex))

    def set_mission_start(self, id_: str, iso_date: str) -> None:
        with self._tx() as c:
            c.execute("UPDATE astronauts SET mission_start = ? WHERE id = ?", (iso_date, id_))

    def get_astronaut(self, id_: str) -> dict | None:
        with self._lock:
            row = self._conn.execute("SELECT * FROM astronauts WHERE id = ?", (id_,)).fetchone()
        return dict(row) if row else None

    def list_astronauts(self) -> list[dict]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT a.*, COALESCE(MAX(r.mission_day), 0) AS mission_day FROM astronauts a "
                "LEFT JOIN readings r ON r.astronaut_id = a.id GROUP BY a.id ORDER BY a.id").fetchall()
        return [dict(r) for r in rows]

    def next_astronaut_id(self) -> str:
        with self._lock:
            n = self._conn.execute("SELECT COUNT(*) FROM astronauts").fetchone()[0]
        while self.get_astronaut(f"A{n + 1:02d}"):
            n += 1
        return f"A{n + 1:02d}"

    # ------------------------------------------------------------------ readings
    def upsert_reading(self, astronaut_id: str, mission_day: int, values: dict, notes: str | None = None) -> None:
        cols = ["astronaut_id", "mission_day"] + READING_COLS + ["notes"]
        params = [astronaut_id, mission_day] + [values.get(c) for c in READING_COLS] + [notes]
        with self._tx() as c:
            c.execute(f"INSERT OR REPLACE INTO readings ({', '.join(cols)}) VALUES ({', '.join('?' * len(cols))})", params)

    def get_reading(self, astronaut_id: str, mission_day: int) -> dict | None:
        with self._lock:
            row = self._conn.execute("SELECT * FROM readings WHERE astronaut_id = ? AND mission_day = ?",
                                     (astronaut_id, mission_day)).fetchone()
        return dict(row) if row else None

    def set_assessment(self, astronaut_id: str, mission_day: int, assessment: dict) -> None:
        with self._tx() as c:
            c.execute("UPDATE readings SET risk_score=?, risk_level=?, predicted_condition=?, assessment_json=? "
                      "WHERE astronaut_id=? AND mission_day=?",
                      (assessment["risk_score"], assessment["risk_level"], assessment["predicted_condition"],
                       json.dumps(assessment), astronaut_id, mission_day))

    def bulk_insert(self, frame: pd.DataFrame) -> None:
        cols = ["astronaut_id", "mission_day"] + READING_COLS + _ML_COLS
        rows = frame.reindex(columns=cols).astype(object).where(frame.reindex(columns=cols).notna(), None).values.tolist()
        with self._tx() as c:
            c.executemany(f"INSERT OR REPLACE INTO readings ({', '.join(cols)}) VALUES ({', '.join('?' * len(cols))})", rows)

    def readings(self, astronaut_id: str, last_n: int | None = None) -> pd.DataFrame:
        sql = "SELECT * FROM readings WHERE astronaut_id = ? ORDER BY mission_day DESC"
        params: tuple = (astronaut_id,)
        if last_n:
            sql += " LIMIT ?"
            params += (last_n,)
        with self._lock:
            df = pd.read_sql_query(sql, self._conn, params=params)
        return df.sort_values("mission_day").reset_index(drop=True)

    # ------------------------------------------------------------------ symptoms
    def add_symptom(self, astronaut_id: str, mission_day: int | None, body_part: str, severity: int, description: str) -> int:
        with self._tx() as c:
            cur = c.execute("INSERT INTO symptoms (astronaut_id, mission_day, body_part, severity, description) "
                            "VALUES (?,?,?,?,?)", (astronaut_id, mission_day, body_part, severity, description))
            return int(cur.lastrowid)

    def symptoms(self, astronaut_id: str, limit: int = 50) -> list[dict]:
        with self._lock:
            rows = self._conn.execute("SELECT * FROM symptoms WHERE astronaut_id = ? ORDER BY id DESC LIMIT ?",
                                      (astronaut_id, limit)).fetchall()
        return [dict(r) for r in rows]

    # ----------------------------------------------------------------- telemetry
    def add_telemetry(self, astronaut_id: str, ts: str, values: dict) -> None:
        cols = ["astronaut_id", "ts"] + TELEMETRY_COLS
        with self._tx() as c:
            c.execute(f"INSERT OR REPLACE INTO telemetry ({', '.join(cols)}) VALUES ({', '.join('?' * len(cols))})",
                      [astronaut_id, ts] + [values.get(k) for k in TELEMETRY_COLS])

    def telemetry(self, astronaut_id: str, limit: int | None = None, date_prefix: str | None = None) -> pd.DataFrame:
        sql, params = "SELECT * FROM telemetry WHERE astronaut_id = ?", [astronaut_id]
        if date_prefix:
            sql += " AND ts LIKE ?"
            params.append(date_prefix + "%")
        sql += " ORDER BY ts DESC"
        if limit:
            sql += " LIMIT ?"
            params.append(limit)
        with self._lock:
            df = pd.read_sql_query(sql, self._conn, params=params)
        return df.sort_values("ts").reset_index(drop=True)

    # ----------------------------------------------------------------- wellbeing
    def add_wellbeing(self, astronaut_id: str, mission_day: int | None, answers: dict, score: int, level: str) -> int:
        with self._tx() as c:
            cur = c.execute("INSERT INTO wellbeing (astronaut_id, mission_day, answers_json, score, level) VALUES (?,?,?,?,?)",
                            (astronaut_id, mission_day, json.dumps(answers), score, level))
            return int(cur.lastrowid)

    def wellbeing(self, astronaut_id: str, limit: int = 30) -> list[dict]:
        with self._lock:
            rows = self._conn.execute("SELECT * FROM wellbeing WHERE astronaut_id = ? ORDER BY id DESC LIMIT ?",
                                      (astronaut_id, limit)).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["answers"] = json.loads(d.pop("answers_json"))
            out.append(d)
        return out
