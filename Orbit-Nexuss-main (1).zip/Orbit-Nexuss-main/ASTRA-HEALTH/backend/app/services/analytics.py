"""Trends, forecasts, hazard mapping and engagement stats."""
from __future__ import annotations

import numpy as np
import pandas as pd

from app.config import settings

TREND_METRICS = ["heart_rate_bpm", "systolic_bp", "diastolic_bp", "body_temp_c", "blood_glucose_mgdl", "spo2_pct",
                 "sleep_hours", "mood_score", "stress_level", "exercise_min", "body_mass_kg",
                 "bone_density_pct_baseline", "cabin_co2_mmhg"]
_RANK = {"green": 0, "amber": 1, "red": 2}


def _r(x, nd=2):
    return None if x is None or pd.isna(x) else round(float(x), nd)


def _slope(days: pd.Series, values: pd.Series) -> float | None:
    ok = values.notna()
    if ok.sum() < 5:
        return None
    return float(np.polyfit(days[ok].astype(float), values[ok].astype(float), 1)[0])


def trends(df: pd.DataFrame) -> dict:
    """Last-7-day mean vs the previous 7 days for each metric."""
    out = {}
    last, prev = df.tail(7), df.iloc[-14:-7] if len(df) >= 14 else df.iloc[0:0]
    for m in TREND_METRICS:
        a, b = last[m].mean(), prev[m].mean() if len(prev) else np.nan
        change = None if pd.isna(a) or pd.isna(b) else a - b
        out[m] = {"last_7d_avg": _r(a), "prev_7d_avg": _r(b), "change": _r(change),
                  "direction": "flat" if change is None or abs(change) < 1e-9 else ("up" if change > 0 else "down")}
    return out


def forecast(df: pd.DataFrame) -> dict:
    """Linear projections to end of mission for slow-moving risks."""
    if df.empty:
        return {}
    day, end = int(df["mission_day"].max()), settings.mission_length_days
    remaining = max(0, end - day)
    recent = df.tail(45)
    out: dict = {"mission_day": day, "mission_length_days": end}

    bone_now, slope = df["bone_density_pct_baseline"].dropna(), _slope(recent["mission_day"], recent["bone_density_pct_baseline"])
    if len(bone_now) and slope is not None:
        now = float(bone_now.iloc[-1])
        out["bone_density"] = {
            "current_pct": _r(now), "loss_pct_per_month": _r(max(-slope * 30, 0.0)),
            "projected_end_of_mission_pct": _r(now + slope * remaining),
            "days_until_90pct": int((now - 90) / -slope) if slope < 0 and now > 90 else None,
        }
    cum, daily = df["cum_radiation_msv"].dropna(), recent["daily_radiation_msv"].dropna()
    if len(cum):
        now, rate, limit = float(cum.iloc[-1]), float(daily.median()) if len(daily) else 0.0, settings.career_radiation_limit_msv  # median: robust to solar-event spikes
        out["radiation"] = {
            "cumulative_msv": _r(now), "avg_daily_msv": _r(rate), "career_limit_msv": limit,
            "pct_of_career_limit": _r(100 * now / limit, 1),
            "projected_end_of_mission_msv": _r(now + rate * remaining),
            "projected_pct_of_career_limit": _r(100 * (now + rate * remaining) / limit, 1),
        }
    for metric, key in (("sleep_hours", "sleep"), ("mood_score", "mood"), ("body_mass_kg", "body_mass")):
        s = _slope(df.tail(14)["mission_day"], df.tail(14)[metric])
        if s is not None:
            out[key] = {"slope_per_week": _r(s * 7), "last_14d_avg": _r(df.tail(14)[metric].mean())}
    return out


def logging_streak(df: pd.DataFrame) -> int:
    """Consecutive mission days logged, counting back from the latest."""
    days = sorted(df["mission_day"].astype(int).tolist(), reverse=True)
    streak = 0
    for i, d in enumerate(days):
        if d != days[0] - i:
            break
        streak += 1
    return streak


def hazards(df: pd.DataFrame, fc: dict) -> list[dict]:
    """Map the record onto NASA HRP's five hazards of human spaceflight."""
    if df.empty:
        return []
    week, latest = df.tail(7), df.iloc[-1]

    def lvl(amber: bool, red: bool) -> str:
        return "red" if red else "amber" if amber else "green"

    rad = fc.get("radiation", {})
    spe_days = int((week["daily_radiation_msv"] >= 2).sum())
    pct = rad.get("projected_pct_of_career_limit") or 0
    h_rad = {"hazard": "Space Radiation", "status": lvl(pct >= 50 or spe_days > 0, pct >= 80 or (latest.get("daily_radiation_msv") or 0) >= 10),
             "metrics": rad | {"elevated_dose_days_last_7": spe_days},
             "summary": f"Cumulative dose {rad.get('cumulative_msv')} mSv ({rad.get('pct_of_career_limit')}% of the career limit)."}

    sleep, mood, stress = week["sleep_hours"].mean(), week["mood_score"].mean(), week["stress_level"].mean()
    h_iso = {"hazard": "Isolation and Confinement",
             "status": lvl(sleep < 6.2 or mood < 5 or stress > 6.5, sleep < 5 or mood < 3.5 or stress > 8),
             "metrics": {"sleep_7d_avg_h": _r(sleep), "mood_7d_avg": _r(mood), "stress_7d_avg": _r(stress),
                         "short_sleep_nights_last_7": int((week["sleep_hours"] < 6).sum())},
             "summary": f"7-day averages: sleep {_r(sleep, 1)} h, mood {_r(mood, 1)}/10, stress {_r(stress, 1)}/10."}

    streak, gaps = logging_streak(df), int(latest["mission_day"]) - len(df)
    h_dist = {"hazard": "Distance from Earth", "status": lvl(streak < 3 or gaps > 5, False),
              "metrics": {"logging_streak_days": streak, "days_logged": len(df), "missed_days": max(gaps, 0),
                          "offline_ready": True, "record_storage": "on-board SQLite"},
              "summary": f"Records are stored on board and guidance works offline. Logging streak: {streak} days."}

    bone = fc.get("bone_density", {})
    cur, ex = bone.get("current_pct") or 100, week["exercise_min"].mean()
    hr_shift = week["heart_rate_bpm"].mean() - df.head(7)["heart_rate_bpm"].mean()
    h_grav = {"hazard": "Gravity Fields", "status": lvl(cur <= 95 or ex < 90, cur <= 90 or ex < 45),
              "metrics": bone | {"exercise_7d_avg_min": _r(ex), "resting_hr_change_since_week1_bpm": _r(hr_shift),
                                 "body_mass_kg": _r(latest.get("body_mass_kg"))},
              "summary": f"Bone density {cur}% of pre-flight, losing {bone.get('loss_pct_per_month')}%/month; exercise {_r(ex, 0)} min/day."}

    co2, co2_max = week["cabin_co2_mmhg"].mean(), week["cabin_co2_mmhg"].max()
    h_env = {"hazard": "Hostile/Closed Environments", "status": lvl(co2_max >= 4, co2_max >= 6 or (latest.get("spo2_pct") or 100) < 92),
             "metrics": {"cabin_co2_7d_avg_mmhg": _r(co2), "cabin_co2_7d_max_mmhg": _r(co2_max),
                         "cabin_temp_c": _r(latest.get("cabin_temp_c")), "cabin_humidity_pct": _r(latest.get("cabin_humidity_pct")),
                         "spo2_latest_pct": _r(latest.get("spo2_pct"))},
             "summary": f"Cabin CO2 averaged {_r(co2, 1)} mmHg this week (peak {_r(co2_max, 1)})."}
    out = [h_rad, h_iso, h_dist, h_grav, h_env]
    needs = {1: ["sleep_hours", "mood_score", "stress_level"], 3: ["bone_density_pct_baseline", "exercise_min"],
             4: ["cabin_co2_mmhg"]}
    for i, cols in needs.items():   # be explicit when a hazard cannot be judged yet
        missing = [c for c in cols if week[c].isna().all()]
        if len(missing) == len(cols):
            out[i]["status"], out[i]["summary"] = "no_data", "Not enough data logged yet: " + ", ".join(missing) + "."
        elif missing:
            out[i]["summary"] += " Not logged yet: " + ", ".join(missing) + "."
    return out


def badges(df: pd.DataFrame) -> list[dict]:
    """Light gamification to encourage consistent logging."""
    streak, week = logging_streak(df), df.tail(7)
    spec = [
        ("streak_7", "7-day logging streak", streak >= 7),
        ("streak_30", "30-day logging streak", streak >= 30),
        ("century", "100 days logged", len(df) >= 100),
        ("iron_crew", "Exercise goal met 5 of last 7 days", int((week["exercise_min"] >= 100).sum()) >= 5),
        ("well_rested", "7+ h average sleep this week", (week["sleep_hours"].mean() or 0) >= 7),
        ("all_clear", "No amber/red days this week", "risk_level" in week and (week["risk_level"] == "green").all()),
    ]
    return [{"id": i, "title": t, "earned": bool(e)} for i, t, e in spec]


def wellbeing_level(score: int) -> str:
    """Score 0-15 from the five-item crew check-in (a simple self-report, not a validated clinical scale)."""
    return "red" if score >= 10 else "amber" if score >= 5 else "green"


_OCCASIONAL = {"blood_glucose_mgdl": ("Blood glucose", 7), "body_mass_kg": ("Body mass", 7),
               "bone_density_pct_baseline": ("Bone density scan", 30), "body_temp_c": ("Body temperature", 3),
               "systolic_bp": ("Blood pressure", 3)}


_ACTION_TITLES = {"daily_radiation_msv": "Follow the solar-event shelter procedure",
                  "cabin_co2_mmhg": "Check the CO2 scrubber and cabin ventilation",
                  "bone_density_pct_baseline": "Review your exercise prescription with the flight surgeon",
                  "sleep_hours": "Protect tonight's sleep window", "mood_score": "Take a break and talk to a crewmate",
                  "stress_level": "Do 5 minutes of paced breathing and lighten today's task list"}


def reminders(df: pd.DataFrame, alerts: list[dict], last_wellbeing_day: int | None) -> list[dict]:
    """Rule-based reminders that keep the health routine going without any ground contact."""
    if df.empty:
        return [{"id": "first_log", "priority": "high", "title": "Log your first set of vitals",
                 "reason": "No readings recorded yet."}]
    day, week, out = int(df["mission_day"].max()), df.tail(7), []
    for a in alerts:
        if a["source"] == "threshold" and a["level"] in ("red", "amber"):
            title = _ACTION_TITLES.get(a["metric"], f"Re-measure {a['metric'].replace('_', ' ')}")
            out.append({"id": f"recheck_{a['metric']}", "priority": "high" if a["level"] == "red" else "medium",
                        "title": title, "reason": a["message"]})
    out.append({"id": "daily_log", "priority": "medium", "title": f"Log mission day {day + 1} vitals, sleep and mood",
                "reason": f"Current logging streak: {logging_streak(df)} days."})
    if last_wellbeing_day is None or day - last_wellbeing_day >= 7:
        out.append({"id": "wellbeing_checkin", "priority": "medium", "title": "Complete the weekly well-being check-in",
                    "reason": "No check-in in the last 7 mission days." if last_wellbeing_day else "No check-in recorded yet."})
    if (short := int((week["sleep_hours"] < 6).sum())) >= 3:
        out.append({"id": "sleep_routine", "priority": "medium", "title": "Start your wind-down routine 1 hour before sleep",
                    "reason": f"{short} of the last 7 nights were under 6 hours."})
    ex = week["exercise_min"].mean()
    if not pd.isna(ex) and ex < 90:
        out.append({"id": "exercise", "priority": "medium", "title": "Complete today's resistive + aerobic exercise block",
                    "reason": f"7-day average is {ex:.0f} min/day; exercise is the main countermeasure for bone and muscle loss."})
    for col, (label, every) in _OCCASIONAL.items():
        logged = df.loc[df[col].notna(), "mission_day"]
        gap = day - int(logged.max()) if len(logged) else None
        if gap is None or gap >= every:
            out.append({"id": f"measure_{col}", "priority": "low", "title": f"Record {label.lower()}",
                        "reason": f"Not logged for {gap} days." if gap is not None else "Never logged."})
    order = {"high": 0, "medium": 1, "low": 2}
    return sorted(out, key=lambda r: order[r["priority"]])
