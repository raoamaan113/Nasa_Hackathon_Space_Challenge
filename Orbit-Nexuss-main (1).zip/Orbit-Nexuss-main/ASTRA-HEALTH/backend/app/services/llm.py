"""LLM assistant (Groq, OpenAI-compatible) with a deterministic offline fallback.

Deep-space missions have long communication delays, so every LLM feature degrades
gracefully to rule-based guidance when the API cannot be reached.
"""
from __future__ import annotations

import json
import logging

import httpx

from app.config import settings

log = logging.getLogger("astrohealth.llm")

SYSTEM_PROMPT = """You are AstroHealth, an on-board health decision-support assistant for an astronaut on a long-duration space mission.

Rules:
- You are decision support, NOT a doctor. Never state a diagnosis. Say what the data "may suggest" and what to check next.
- Ground every statement in the ASTRONAUT DATA provided. Quote the actual numbers and compare them with the astronaut's personal baseline. If the data does not cover the question, say so.
- Be calm, clear and brief: plain language, short sentences, at most ~150 words unless asked for more.
- Give 2-4 concrete next steps the astronaut can do on board (re-measure, rest, hydrate, check cabin systems, exercise, sleep hygiene).
- For any RED alert, or chest pain, breathing difficulty, fainting, confusion, severe pain or thoughts of self-harm: tell them to contact the flight surgeon / mission control immediately and involve a crewmate.
- Do not recommend prescription drugs or doses. Refer to the on-board medical kit procedures and the flight surgeon.
- Relate findings to spaceflight hazards (radiation, isolation, microgravity, closed cabin) only when relevant."""


class LLMService:
    def __init__(self, api_key: str | None = None, base_url: str | None = None,
                 models: tuple[str, ...] | None = None, transport: httpx.BaseTransport | None = None) -> None:
        self.api_key = settings.groq_api_key if api_key is None else api_key
        self.base_url = (base_url or settings.groq_base_url).rstrip("/")
        self.models = list(models or settings.groq_models)
        self._transport = transport

    @property
    def configured(self) -> bool:
        return bool(self.api_key)

    def _client(self) -> httpx.Client:
        return httpx.Client(timeout=settings.llm_timeout_s, transport=self._transport,
                            headers={"Authorization": f"Bearer {self.api_key}"})

    def available_models(self) -> list[str]:
        with self._client() as c:
            r = c.get(f"{self.base_url}/models")
            r.raise_for_status()
            return sorted(m["id"] for m in r.json().get("data", []))

    def complete(self, messages: list[dict], max_tokens: int = 900) -> tuple[str, str] | None:
        """Return (text, model) or None when the LLM is unreachable. Tries each model in order."""
        if not self.configured:
            return None
        try:
            with self._client() as c:
                for model in self.models:
                    r = c.post(f"{self.base_url}/chat/completions", json={
                        "model": model, "messages": messages, "temperature": 0.3, "max_completion_tokens": max_tokens})
                    if r.status_code in (400, 404):      # model retired / unknown -> try the next one
                        log.warning("model %s rejected (%s): %s", model, r.status_code, r.text[:200])
                        continue
                    r.raise_for_status()
                    text = (r.json()["choices"][0]["message"].get("content") or "").strip()
                    if text:
                        if model != self.models[0]:      # remember the model that works
                            self.models.remove(model)
                            self.models.insert(0, model)
                        return text, model
        except (httpx.HTTPError, KeyError, IndexError, ValueError) as exc:
            log.warning("LLM unavailable, using offline guidance: %s", exc)
        return None

    # ------------------------------------------------------------------ features
    def chat(self, context: dict, message: str, history: list[dict]) -> dict:
        msgs = [{"role": "system", "content": SYSTEM_PROMPT},
                {"role": "system", "content": "ASTRONAUT DATA (JSON):\n" + json.dumps(context, default=str)}]
        msgs += [{"role": h["role"], "content": h["content"]} for h in history[-8:]]
        msgs.append({"role": "user", "content": message})
        if (res := self.complete(msgs)):
            return {"reply": res[0], "source": "llm", "model": res[1]}
        return {"reply": offline_reply(context, message), "source": "offline", "model": None}

    def daily_summary(self, context: dict) -> dict:
        prompt = ("Write today's health briefing for this astronaut: (1) one-line overall status with the colour level, "
                  "(2) what changed versus their personal baseline, (3) the single most important thing to do today, "
                  "(4) one encouraging note. Under 130 words.")
        return self.chat(context, prompt, [])


def offline_reply(context: dict, message: str = "") -> str:
    """Rule-based answer built only from on-board data (no network needed)."""
    latest, alerts = context.get("latest_reading", {}), context.get("active_alerts", [])
    lines = [f"[Offline guidance - no link to the AI service] Mission day {context.get('mission_day')}: "
             f"overall status {str(context.get('overall_level', 'green')).upper()}, "
             f"ML risk score {context.get('ml_assessment', {}).get('risk_score', 'n/a')}/100."]
    if alerts:
        lines.append("What needs attention:")
        lines += [f"- {a['message']} Next step: {a['guidance']}" for a in alerts[:4]]
        if any(a["level"] == "red" for a in alerts):
            lines.append("At least one RED alert is active: contact the flight surgeon / mission control now and tell a crewmate.")
    else:
        vit = ", ".join(f"{k.replace('_', ' ')} {v}" for k, v in latest.items()
                        if k in ("heart_rate_bpm", "systolic_bp", "body_temp_c", "spo2_pct", "sleep_hours", "mood_score") and v is not None)
        lines.append(f"All logged values are within expected ranges ({vit}). Keep up exercise, hydration and your sleep schedule.")
    flagged = [h for h in context.get("hazards", []) if h["status"] != "green"]
    if flagged:
        lines.append("Hazard watch: " + " ".join(f"{h['hazard']} ({h['status']}): {h['summary']}" for h in flagged))
    lines.append("This is decision support, not a diagnosis.")
    return "\n".join(lines)
