"""Colour-coded threshold alerts and plain-language guidance.

Thresholds are conservative clinical screening bands (not mission flight rules).
They catch absolute danger values; the ML engine catches personal-baseline shifts.
"""
from __future__ import annotations

import math

from app.services.reference import STANDARDS

# metric -> (label, unit, [(level, predicate, message)]) ; first matching rule wins (red listed first)
_RULES: dict[str, tuple[str, str, list]] = {
    "heart_rate_bpm": ("Heart rate", "bpm", [
        ("red", lambda v: v > 120 or v < 40, "far outside the resting range"),
        ("amber", lambda v: v > 100 or v < 45, "outside the normal resting range")]),
    "resp_rate_bpm": ("Respiratory rate", "breaths/min", [
        ("red", lambda v: v > 24 or v < 8, "markedly abnormal"),
        ("amber", lambda v: v > 20 or v < 10, "outside the normal range")]),
    "systolic_bp": ("Systolic blood pressure", "mmHg", [
        ("red", lambda v: v >= 160 or v < 90, "in a range that needs prompt attention"),
        ("amber", lambda v: v >= 135, "elevated")]),
    "diastolic_bp": ("Diastolic blood pressure", "mmHg", [
        ("red", lambda v: v >= 100 or v < 50, "in a range that needs prompt attention"),
        ("amber", lambda v: v >= 88, "elevated")]),
    "body_temp_c": ("Body temperature", "°C", [
        ("red", lambda v: v >= 38.5 or v < 35.0, "indicates significant fever or hypothermia"),
        ("amber", lambda v: v >= 37.6 or v < 35.6, "slightly outside normal")]),
    "blood_glucose_mgdl": ("Blood glucose", "mg/dL", [
        ("red", lambda v: v >= 200 or v < 54, "in a dangerous range"),
        ("amber", lambda v: v >= 140 or v < 70, "outside the normal range")]),
    "spo2_pct": ("Blood oxygen (SpO2)", "%", [
        ("red", lambda v: v < 92, "low - check cabin air and breathing now"),
        ("amber", lambda v: v < 95, "slightly low")]),
    "sleep_hours": ("Sleep duration", "h", [
        ("red", lambda v: v < 4, "severely short"),
        ("amber", lambda v: v < 6, "below the recommended amount")]),
    "mood_score": ("Mood", "/10", [
        ("red", lambda v: v <= 2.5, "very low"),
        ("amber", lambda v: v <= 4, "low")]),
    "stress_level": ("Stress", "/10", [
        ("red", lambda v: v >= 9, "very high"),
        ("amber", lambda v: v >= 7, "high")]),
    "cabin_co2_mmhg": ("Cabin CO2", "mmHg", [
        ("red", lambda v: v >= 6, "high - expect headaches and impaired thinking"),
        ("amber", lambda v: v >= 4, "elevated")]),
    "daily_radiation_msv": ("Daily radiation dose", "mSv", [
        ("red", lambda v: v >= 10, "very high - possible solar particle event"),
        ("amber", lambda v: v >= 2, "above the usual background")]),
    "bone_density_pct_baseline": ("Bone density", "% of pre-flight", [
        ("red", lambda v: v <= 90, "more than 10% below pre-flight"),
        ("amber", lambda v: v <= 95, "more than 5% below pre-flight")]),
}

GUIDANCE: dict[str, str] = {
    "heart_rate_bpm": "Rest for 10 minutes, hydrate, then re-measure. If it persists or you feel chest pain, palpitations or dizziness, contact the flight surgeon.",
    "resp_rate_bpm": "Sit still and re-measure. Check cabin CO2. Report shortness of breath to the flight surgeon.",
    "systolic_bp": "Rest seated for 5 minutes and re-measure twice. Reduce salt and caffeine. Report repeated high readings, headache or vision changes.",
    "diastolic_bp": "Rest seated for 5 minutes and re-measure twice. Report repeated high readings.",
    "body_temp_c": "Rest, hydrate and re-check in 2 hours. Limit close contact with crew. Report a fever above 38.5 °C or one lasting over 24 hours.",
    "blood_glucose_mgdl": "Re-test in 15 minutes. If low, take fast-acting carbohydrate. If high, hydrate and avoid sugary food. Report repeated abnormal values.",
    "spo2_pct": "Check the sensor fit, breathe slowly and re-measure. Check cabin CO2 and move to a well-ventilated module. Low oxygen with symptoms is urgent.",
    "sleep_hours": "Protect tonight's sleep window: dim lights, no caffeine after midday, no screens 1 hour before sleep. Tell the crew lead if this is the third short night.",
    "mood_score": "Take a break, contact family or a crewmate, and do a favourite activity. Low mood lasting several days is worth a private conference with behavioural health.",
    "stress_level": "Try 5 minutes of paced breathing, some exercise and a lighter task list. Raise workload concerns with mission control.",
    "cabin_co2_mmhg": "Check the CO2 scrubber and airflow, avoid dead-air corners, and rest if you have a headache. Report to mission control.",
    "daily_radiation_msv": "Follow the solar-event procedure: move to the shielded area and limit EVA. Dose is logged to your record.",
    "bone_density_pct_baseline": "Keep to the full resistive-exercise prescription and check vitamin D and calcium intake. Flag the trend at the next medical conference.",
    "fever": "Pattern resembles a fever/infection. Rest, hydrate, monitor temperature every 4 hours and limit crew contact.",
    "tachycardia": "Heart rate is well above YOUR normal. Rest, hydrate, avoid caffeine and re-measure; report palpitations or chest discomfort.",
    "hypertension": "Blood pressure is well above YOUR normal. Rest, re-measure twice and report if it stays high.",
    "hyperglycemia": "Glucose is well above YOUR normal. Re-test, hydrate and review recent meals.",
    "hypoxia_co2": "Pattern suggests a cabin air problem (CO2 up, oxygen saturation down). Check scrubbers and ventilation now.",
    "sleep_deprivation_low_mood": "Sleep and mood have both dropped below YOUR normal. Prioritise rest and talk to a crewmate or behavioural health.",
    "unusual_pattern": "Today's readings are unusual for you even though no single value is in a danger zone. Re-measure and keep an eye on how you feel.",
}
_LEVEL_RANK = {"green": 0, "amber": 1, "red": 2}


def threshold_alerts(reading: dict) -> list[dict]:
    alerts = []
    for metric, (label, unit, rules) in _RULES.items():
        v = reading.get(metric)
        if v is None or (isinstance(v, float) and math.isnan(v)):
            continue
        for level, pred, text in rules:
            if pred(v):
                alerts.append({"source": "threshold", "level": level, "metric": metric, "value": round(float(v), 2),
                               "message": f"{label} is {round(float(v), 1)} {unit} - {text}.", "guidance": GUIDANCE[metric]})
                break
    # second layer: the team's mission standards file (data/external/documentation)
    flagged = {a["metric"] for a in alerts}
    for metric, std in STANDARDS.items():
        v = reading.get(metric)
        if metric in flagged or v is None or (isinstance(v, float) and math.isnan(v)):
            continue
        if v < std["warning_low"] or v > std["warning_high"]:
            alerts.append({"source": "threshold", "level": "amber", "metric": metric, "value": round(float(v), 2),
                           "message": f"{std['parameter']} is {round(float(v), 1)} {std['unit']} - outside the mission warning band "
                                      f"({std['warning_low']:g}-{std['warning_high']:g}).",
                           "guidance": GUIDANCE.get(metric, GUIDANCE["unusual_pattern"])})
    return alerts


def ml_alert(assessment: dict) -> dict | None:
    if assessment["risk_level"] == "green":
        return None
    cond = assessment["predicted_condition"]
    key = cond if cond in GUIDANCE and cond != "normal" else "unusual_pattern"
    devs = ", ".join(f"{d['vital']} {d['value']} (your baseline {d['personal_baseline']})" for d in assessment["top_deviations"])
    name = key.replace("_", " ")
    return {"source": "ml", "level": assessment["risk_level"], "metric": key, "value": float(assessment["risk_score"]),
            "message": f"ML risk score {assessment['risk_score']}/100 - pattern: {name}." + (f" Biggest changes: {devs}." if devs else ""),
            "guidance": GUIDANCE[key]}


def combine(reading: dict, assessment: dict | None) -> tuple[list[dict], str]:
    """All alerts for a reading (worst first) and the overall level."""
    alerts = threshold_alerts(reading)
    if assessment and (m := ml_alert(assessment)):
        alerts.append(m)
    alerts.sort(key=lambda a: -_LEVEL_RANK[a["level"]])
    overall = max((a["level"] for a in alerts), key=_LEVEL_RANK.get, default="green")
    return alerts, overall
