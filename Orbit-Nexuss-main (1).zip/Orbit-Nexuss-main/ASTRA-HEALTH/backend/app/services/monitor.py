"""Application service: ties storage, the ML engine, alert rules and the LLM together."""
from __future__ import annotations

import json
import logging
import math
from datetime import date, datetime, timedelta, timezone

import pandas as pd

from app.config import settings
from app.database import READING_COLS, TELEMETRY_COLS, Database
from app.ml.engine import HealthEngine
from app.schemas import WELLBEING_ITEMS
from app.services import analytics, reference, rules
from app.services.llm import LLMService

log = logging.getLogger("astrohealth")
SEED_NAMES = ["Cmdr. Aisha Khan", "Dr. Leo Martins", "Eng. Sana Tariq", "Pilot Omar Reyes",
              "Dr. Mei Tanaka", "Spec. Daniel Okoye", "Eng. Hira Baig", "Dr. Ivan Petrov"]
SEED_DAYS = 120   # demo crew starts mid-mission so new logs and forecasts are meaningful


class NotFound(Exception):
    pass


def _clean(d: dict) -> dict:
    return {k: (None if isinstance(v, float) and math.isnan(v) else v) for k, v in d.items()}


def _row(row: pd.Series) -> dict:
    d = _clean(row.to_dict())
    d["assessment"] = json.loads(d.pop("assessment_json")) if d.get("assessment_json") else None
    return d


class HealthMonitor:
    def __init__(self, db: Database, engine: HealthEngine, llm: LLMService) -> None:
        self.db, self.engine, self.llm = db, engine, llm

    # ---------------------------------------------------------------------- seed
    def seed_demo_crew(self) -> int:
        """Load the first N synthetic astronauts (scored by the engine) into an empty database."""
        if self.db.list_astronauts() or not settings.data_csv.exists():
            return 0
        df = pd.read_csv(settings.data_csv)
        ids = sorted(df["astronaut_id"].unique())[: settings.seed_crew]
        df = df[df["astronaut_id"].isin(ids) & (df["mission_day"] <= SEED_DAYS)].sort_values(["astronaut_id", "mission_day"])
        assessments = [a.to_dict() for a in self.engine.score_frame(df)]
        df = df.assign(risk_score=[a["risk_score"] for a in assessments], risk_level=[a["risk_level"] for a in assessments],
                       predicted_condition=[a["predicted_condition"] for a in assessments],
                       assessment_json=[json.dumps(a) for a in assessments])
        for i, aid in enumerate(ids):
            first = df[df["astronaut_id"] == aid].iloc[0]
            self.db.add_astronaut(aid, SEED_NAMES[i % len(SEED_NAMES)], int(first["age"]), str(first["sex"]))
        self.db.bulk_insert(df)
        log.info("seeded %d astronauts x %d days", len(ids), SEED_DAYS)
        return len(ids)

    def seed_telemetry_stream(self) -> int:
        """Load the bundled wearable telemetry stream (hourly samples) through the normal ingestion path."""
        if not settings.telemetry_csv.exists():
            return 0
        raw = pd.read_csv(settings.telemetry_csv)
        raw["id"] = raw["Astronaut_ID"].str.extract(r"^([\w-]+)")[0]
        if self.db.get_astronaut(raw["id"].iloc[0]):
            return 0
        for full, aid in raw[["Astronaut_ID", "id"]].drop_duplicates().itertuples(index=False):
            self.db.add_astronaut(aid, full.replace("(", "- ").replace(")", ""), None, None)
        cols = {"Heart_Rate_bpm": "heart_rate_bpm", "Systolic_BP_mmHg": "systolic_bp", "Diastolic_BP_mmHg": "diastolic_bp",
                "SpO2_Percent": "spo2_pct", "Radiation_Exposure_mSv": "daily_radiation_msv",
                "Sleep_Quality_Score": "sleep_quality", "Behavioral_Mood_Score": "mood_score"}
        samples = [{"astronaut_id": r["id"], "timestamp": datetime.fromisoformat(r["Timestamp"])}
                   | {v: float(r[k]) for k, v in cols.items()} for _, r in raw.iterrows()]
        self.ingest_telemetry(samples)
        log.info("ingested %d telemetry samples", len(samples))
        return len(samples)

    # ---------------------------------------------------------------- astronauts
    def _require(self, astronaut_id: str) -> dict:
        if not (a := self.db.get_astronaut(astronaut_id)):
            raise NotFound(f"astronaut '{astronaut_id}' not found")
        return a

    def list_astronauts(self) -> list[dict]:
        out = []
        for a in self.db.list_astronauts():
            hist = self.db.readings(a["id"])
            out.append(a | {"logging_streak_days": analytics.logging_streak(hist) if len(hist) else 0})
        return out

    def crew_overview(self) -> list[dict]:
        """Commander / flight-surgeon view: everyone's status, most urgent first."""
        rank, out = {"red": 0, "amber": 1, "green": 2}, []
        for a in self.db.list_astronauts():
            last = self.db.readings(a["id"], last_n=1)
            if last.empty:
                out.append({"astronaut_id": a["id"], "name": a["name"], "mission_day": 0, "overall_level": "green",
                            "risk_score": None, "predicted_condition": None, "top_alert": None, "n_alerts": 0})
                continue
            row = _row(last.iloc[-1])
            alerts, overall = rules.combine(row, row["assessment"])
            out.append({"astronaut_id": a["id"], "name": a["name"], "mission_day": int(row["mission_day"]),
                        "overall_level": overall, "risk_score": row["risk_score"], "predicted_condition": row["predicted_condition"],
                        "top_alert": alerts[0]["message"] if alerts else None, "n_alerts": len(alerts)})
        return sorted(out, key=lambda r: (rank[r["overall_level"]], -(r["risk_score"] or 0)))

    def create_astronaut(self, name: str, age: int, sex: str, id_: str | None = None) -> dict:
        id_ = id_ or self.db.next_astronaut_id()
        if self.db.get_astronaut(id_):
            raise ValueError(f"astronaut id '{id_}' already exists")
        self.db.add_astronaut(id_, name, age, sex)
        return {"id": id_, "name": name, "age": age, "sex": sex, "mission_day": 0, "logging_streak_days": 0}

    # ------------------------------------------------------------------ readings
    def log_reading(self, payload: dict) -> dict:
        aid = payload["astronaut_id"]
        self._require(aid)
        prior = self.db.readings(aid, last_n=1)
        day = payload.get("mission_day") or (int(prior["mission_day"].iloc[-1]) if len(prior) else 0) + 1
        return self._store_and_score(aid, day, {c: payload.get(c) for c in READING_COLS}, payload.get("notes"))

    def _store_and_score(self, aid: str, day: int, values: dict, notes: str | None) -> dict:
        """Persist one daily record, run the ML engine on it and build the alert list."""
        history = self.db.readings(aid)
        prev_cum = history.loc[history["mission_day"] < day, "cum_radiation_msv"].dropna()
        values["cum_radiation_msv"] = round((float(prev_cum.iloc[-1]) if len(prev_cum) else 0.0)
                                            + (values.get("daily_radiation_msv") or 0.0), 2)
        self.db.upsert_reading(aid, day, values, notes)
        history = self.db.readings(aid)
        assessment = self.engine.score_latest(history[history["mission_day"] <= day].tail(20)).to_dict()
        self.db.set_assessment(aid, day, assessment)
        alerts, overall = rules.combine(values, assessment)
        return {"astronaut_id": aid, "mission_day": day, "overall_level": overall, "assessment": assessment,
                "alerts": alerts, "reading": _clean(values)}

    # ----------------------------------------------------------------- telemetry
    def ingest_telemetry(self, samples: list[dict]) -> dict:
        """Store raw sensor samples, then roll each affected day up into the daily record and re-score it."""
        touched: dict[str, set[date]] = {}
        for s in samples:
            a = self._require(s["astronaut_id"])
            ts = s.get("timestamp") or datetime.now(timezone.utc)
            ts = ts.astimezone(timezone.utc).replace(tzinfo=None) if ts.tzinfo else ts
            if not a.get("mission_start"):          # telemetry continues after any days already logged by hand
                last = self.db.readings(a["id"], last_n=1)
                offset = int(last["mission_day"].iloc[-1]) if len(last) else 0
                self.db.set_mission_start(a["id"], (ts.date() - timedelta(days=offset)).isoformat())
            self.db.add_telemetry(a["id"], ts.isoformat(sep=" ", timespec="seconds"), s)
            touched.setdefault(a["id"], set()).add(ts.date())

        results = {}
        for aid, days in touched.items():
            start = date.fromisoformat(self.db.get_astronaut(aid)["mission_start"])
            for d in sorted(days):
                mission_day = (d - start).days + 1
                if mission_day < 1:
                    raise ValueError(f"telemetry dated {d} is before {aid}'s mission start ({start})")
                tel = self.db.telemetry(aid, date_prefix=d.isoformat())
                existing = self.db.get_reading(aid, mission_day) or {}
                values = {c: existing.get(c) for c in READING_COLS}
                values.update({c: round(float(tel[c].mean()), 2) for c in TELEMETRY_COLS if tel[c].notna().any()})
                results[aid] = self._store_and_score(aid, mission_day, values, existing.get("notes")) | {"samples_today": len(tel)}
        return {"samples_stored": len(samples), "latest": list(results.values())}

    def telemetry(self, astronaut_id: str, limit: int) -> list[dict]:
        self._require(astronaut_id)
        return [_clean(r) for r in self.db.telemetry(astronaut_id, limit=limit).to_dict("records")]

    def readings(self, astronaut_id: str, days: int) -> list[dict]:
        self._require(astronaut_id)
        return [_row(r) for _, r in self.db.readings(astronaut_id, last_n=days).iterrows()]

    def series(self, astronaut_id: str, metric: str, days: int) -> dict:
        self._require(astronaut_id)
        if metric not in READING_COLS + ["risk_score"]:
            raise ValueError(f"unknown metric '{metric}'")
        df = self.db.readings(astronaut_id, last_n=days)
        vals = [None if pd.isna(v) else float(v) for v in df[metric]]
        return {"astronaut_id": astronaut_id, "metric": metric, "mission_days": df["mission_day"].astype(int).tolist(),
                "values": vals, "risk_levels": df["risk_level"].tolist()}

    # ----------------------------------------------------------------- dashboard
    def _frame(self, astronaut_id: str) -> pd.DataFrame:
        self._require(astronaut_id)
        return self.db.readings(astronaut_id)

    def alerts(self, astronaut_id: str, days: int = 7) -> list[dict]:
        out = []
        for _, r in self._frame(astronaut_id).tail(days).iloc[::-1].iterrows():
            row = _row(r)
            alerts, _ = rules.combine(row, row["assessment"])
            out += [{"mission_day": int(row["mission_day"])} | a for a in alerts]
        return out

    def forecast(self, astronaut_id: str) -> dict:
        return analytics.forecast(self._frame(astronaut_id))

    def hazards(self, astronaut_id: str) -> list[dict]:
        df = self._frame(astronaut_id)
        return analytics.hazards(df, analytics.forecast(df))

    def dashboard(self, astronaut_id: str) -> dict:
        astronaut = self._require(astronaut_id)
        df = self.db.readings(astronaut_id)
        if df.empty:
            return {"astronaut": astronaut, "mission_day": 0, "overall_level": "green", "latest_reading": None,
                    "assessment": None, "alerts": [], "trends": {}, "forecast": {}, "hazards": [],
                    "engagement": {"logging_streak_days": 0, "days_logged": 0, "badges": []}, "recent_symptoms": [],
                    "reminders": analytics.reminders(df, [], None), "wellbeing": None}
        latest = _row(df.iloc[-1])
        alerts, overall = rules.combine(latest, latest["assessment"])
        fc = analytics.forecast(df)
        checkins = self.db.wellbeing(astronaut_id, limit=1)
        return {
            "reminders": analytics.reminders(df, alerts, checkins[0]["mission_day"] if checkins else None),
            "wellbeing": checkins[0] if checkins else None,
            "astronaut": astronaut, "mission_day": int(latest["mission_day"]), "overall_level": overall,
            "latest_reading": {k: latest[k] for k in READING_COLS + ["notes"]},
            "assessment": latest["assessment"], "alerts": alerts,
            "trends": analytics.trends(df), "forecast": fc, "hazards": analytics.hazards(df, fc),
            "risk_history": {"mission_days": df["mission_day"].tail(30).astype(int).tolist(),
                             "risk_scores": [None if pd.isna(v) else int(v) for v in df["risk_score"].tail(30)]},
            "engagement": {"logging_streak_days": analytics.logging_streak(df), "days_logged": len(df),
                           "badges": analytics.badges(df)},
            "recent_symptoms": self.db.symptoms(astronaut_id, limit=5),
            "disclaimer": "Decision support only - not a medical diagnosis.",
        }

    # ------------------------------------------------------------------ symptoms
    def add_symptom(self, payload: dict) -> dict:
        self._require(payload["astronaut_id"])
        day = payload.get("mission_day")
        if day is None:
            last = self.db.readings(payload["astronaut_id"], last_n=1)
            day = int(last["mission_day"].iloc[-1]) if len(last) else None
        sid = self.db.add_symptom(payload["astronaut_id"], day, payload["body_part"].lower().strip(),
                                  payload["severity"], payload.get("description", ""))
        return {"id": sid, "mission_day": day, **{k: payload[k] for k in ("astronaut_id", "body_part", "severity")},
                "description": payload.get("description", "")}

    def symptoms(self, astronaut_id: str) -> list[dict]:
        self._require(astronaut_id)
        return self.db.symptoms(astronaut_id)

    # ---------------------------------------------------- wellbeing / reminders
    def add_wellbeing(self, payload: dict) -> dict:
        aid = payload["astronaut_id"]
        self._require(aid)
        answers = {k: payload[k] for k in WELLBEING_ITEMS}
        score = sum(answers.values())
        level = analytics.wellbeing_level(score)
        last = self.db.readings(aid, last_n=1)
        day = int(last["mission_day"].iloc[-1]) if len(last) else None
        wid = self.db.add_wellbeing(aid, day, answers, score, level)
        top = [WELLBEING_ITEMS[k] for k, v in sorted(answers.items(), key=lambda kv: -kv[1]) if v >= 2]
        advice = {"green": "Well-being looks steady. Keep your routines and crew time.",
                  "amber": "Some strain is showing. Protect sleep, schedule family or crew time and tell the crew lead how you are doing.",
                  "red": "Sustained strain. Request a private conference with behavioural health / the flight surgeon and lean on a crewmate today."}[level]
        return {"id": wid, "astronaut_id": aid, "mission_day": day, "score": score, "max_score": 15, "level": level,
                "main_concerns": top, "guidance": advice,
                "note": "Simple self-report check-in, not a validated clinical scale."}

    def wellbeing(self, astronaut_id: str) -> list[dict]:
        self._require(astronaut_id)
        return self.db.wellbeing(astronaut_id)

    def reminders(self, astronaut_id: str) -> list[dict]:
        return self.dashboard(astronaut_id)["reminders"]

    def export_record(self, astronaut_id: str) -> dict:
        """Complete portable health record (for handover to the flight surgeon or offline backup)."""
        astronaut = self._require(astronaut_id)
        df = self.db.readings(astronaut_id)
        return {"exported_at": datetime.now(timezone.utc).isoformat(timespec="seconds"), "astronaut": astronaut,
                "readings": [_row(r) for _, r in df.iterrows()], "symptoms": self.db.symptoms(astronaut_id, limit=10_000),
                "wellbeing_checkins": self.db.wellbeing(astronaut_id, limit=10_000),
                "forecast": analytics.forecast(df), "hazards": analytics.hazards(df, analytics.forecast(df)) if len(df) else [],
                "standards": reference.STANDARDS}

    def export_csv(self, astronaut_id: str) -> str:
        self._require(astronaut_id)
        return self.db.readings(astronaut_id).drop(columns=["assessment_json"]).to_csv(index=False)

    # ----------------------------------------------------------------------- LLM
    def llm_context(self, astronaut_id: str) -> dict:
        """Compact, numbers-only snapshot given to the LLM (and to the offline fallback)."""
        d = self.dashboard(astronaut_id)
        a = d["astronaut"]
        return {
            "astronaut": {"id": a["id"], "age": a["age"], "sex": a["sex"]},
            "mission_day": d["mission_day"], "overall_level": d["overall_level"],
            "latest_reading": {k: v for k, v in (d["latest_reading"] or {}).items() if v is not None},
            "ml_assessment": d["assessment"] or {}, "active_alerts": d["alerts"],
            "seven_day_trends": {k: v for k, v in d["trends"].items() if v["last_7d_avg"] is not None},
            "forecast": d["forecast"],
            "hazards": [{k: h[k] for k in ("hazard", "status", "summary")} for h in d["hazards"]],
            "recent_symptoms": [{k: s[k] for k in ("mission_day", "body_part", "severity", "description")} for s in d["recent_symptoms"]],
            "latest_wellbeing_checkin": ({k: d["wellbeing"][k] for k in ("mission_day", "score", "level", "answers")}
                                         if d.get("wellbeing") else None),
            "open_reminders": [r["title"] for r in d.get("reminders", [])[:5]],
        }

    def chat(self, astronaut_id: str, message: str, history: list[dict]) -> dict:
        return self.llm.chat(self.llm_context(astronaut_id), message, history)

    def daily_summary(self, astronaut_id: str) -> dict:
        return self.llm.daily_summary(self.llm_context(astronaut_id))
