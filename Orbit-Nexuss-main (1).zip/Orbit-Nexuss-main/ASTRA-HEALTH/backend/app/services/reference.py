"""Reference data supplied with the project: mission standards and the NASA OSDR study record."""
from __future__ import annotations

import csv
import json
from functools import lru_cache

from app.config import settings

_PARAM_TO_METRIC = {
    "Heart Rate": "heart_rate_bpm", "Systolic BP": "systolic_bp", "Diastolic BP": "diastolic_bp",
    "Blood Oxygen (SpO2)": "spo2_pct", "Sleep Duration": "sleep_hours",
    "Radiation Exposure": "daily_radiation_msv", "Mood / Behavioral Score": "mood_score",
}


def load_standards() -> dict[str, dict]:
    """metric -> {parameter, unit, earth_baseline, warning_low, warning_high} from the standards CSV."""
    if not settings.standards_csv.exists():
        return {}
    out = {}
    with settings.standards_csv.open(newline="", encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            metric = _PARAM_TO_METRIC.get(row["Parameter"].strip())
            if metric:
                out[metric] = {"parameter": row["Parameter"].strip(), "unit": row["Unit"].strip(),
                               "earth_baseline": float(row["Normal_Earth_Baseline"]),
                               "warning_low": float(row["Space_Warning_Low"]), "warning_high": float(row["Space_Warning_High"])}
    return out


STANDARDS = load_standards()


@lru_cache(maxsize=1)
def nasa_study() -> dict:
    """Compact summary of the bundled NASA OSDR study metadata."""
    if not settings.nasa_study_json.exists():
        return {}
    m = json.loads(settings.nasa_study_json.read_text(encoding="utf-8"))

    def name(x):
        return x.get("annotationValue") if isinstance(x, dict) else x

    organisms = m.get("organisms")
    if isinstance(organisms, dict):
        organisms = sorted(organisms.get("links", organisms))
    return {
        "accession": m.get("accession"), "title": m.get("title"), "project_title": m.get("projectTitle"),
        "project_type": m.get("projectType"), "flight_program": m.get("flightProgram"),
        "mission": m.get("missionName"), "mission_start": m.get("missionStart"), "mission_end": m.get("missionEnd"),
        "managing_center": m.get("managingNasaCenter"), "organisms": organisms, "doi": m.get("doi"),
        "license": m.get("licenseName"), "description": m.get("description"),
        "assays": [{"measurement": name(a.get("measurementType")), "technology": name(a.get("technologyType")),
                    "data_files": len(a.get("dataFiles", []))} for a in m.get("assays", [])],
        "source": "NASA Open Science Data Repository (OSDR)",
        "how_it_is_used": "Scientific context only. It is a rodent spaceflight study (skeletal-muscle gene expression in "
                          "microgravity) that supports the Gravity Fields hazard. It contains no astronaut vital signs "
                          "and is not used to train the ML models.",
    }
