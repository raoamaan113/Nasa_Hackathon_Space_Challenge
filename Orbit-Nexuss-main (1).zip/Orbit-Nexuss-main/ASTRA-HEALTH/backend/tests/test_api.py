"""End-to-end API tests. The LLM is replaced by a mock transport (no network needed)."""
import json

import httpx
import pandas as pd
import pytest
from fastapi.testclient import TestClient

from app.config import settings
from app.main import create_app, load_engine
from app.ml.features import FEATURE_COLS, build_features
from app.services.llm import LLMService

NORMAL = dict(heart_rate_bpm=62, hrv_ms=60, resp_rate_bpm=14, systolic_bp=116, diastolic_bp=74, body_temp_c=36.6,
              blood_glucose_mgdl=88, spo2_pct=98, sleep_hours=7.2, sleep_quality=7.5, mood_score=7, stress_level=3.5,
              exercise_min=120, body_mass_kg=78, bone_density_pct_baseline=99.5, cabin_co2_mmhg=2.6, cabin_temp_c=22.5,
              cabin_humidity_pct=45, daily_radiation_msv=0.6)


@pytest.fixture(scope="session")
def engine():
    return load_engine()


def _llm(handler):
    return LLMService(api_key="test-key", models=("model-a", "model-b"), transport=httpx.MockTransport(handler))


def _ok(request: httpx.Request) -> httpx.Response:
    body = json.loads(request.content)
    assert request.headers["authorization"] == "Bearer test-key"
    assert body["messages"][0]["role"] == "system" and "ASTRONAUT DATA" in body["messages"][1]["content"]
    return httpx.Response(200, json={"choices": [{"message": {"content": f"mock reply from {body['model']}"}}]})


def _down(request: httpx.Request) -> httpx.Response:
    raise httpx.ConnectError("no link to Earth")


@pytest.fixture()
def client(engine):
    with TestClient(create_app(db_path=":memory:", llm=_llm(_ok), engine=engine)) as c:
        yield c


def _new_astronaut(client) -> str:
    r = client.post("/api/v1/astronauts", json={"name": "Test Pilot", "age": 40, "sex": "F"})
    assert r.status_code == 201
    return r.json()["id"]


def _log_days(client, aid, n, **override):
    last = None
    for _ in range(n):
        last = client.post("/api/v1/readings", json={"astronaut_id": aid, **NORMAL, **override})
        assert last.status_code == 201, last.text
    return last.json()


# ---------------------------------------------------------------- meta / seed
def test_health_and_seed(client):
    assert client.get("/health").json()["status"] == "ok"
    crew = client.get("/api/v1/astronauts").json()
    assert len(crew) == settings.seed_crew + 3 and crew[0]["mission_day"] == 120 and crew[0]["logging_streak_days"] == 120


def test_ml_metrics_exposed(client):
    m = client.get("/api/v1/ml/metrics").json()
    assert m["classifier"]["anomaly_roc_auc"] > 0.9 and "caveat" in m


# ---------------------------------------------------------------- ML engine
def test_features_have_no_nans_in_model_inputs():
    df = pd.read_csv(settings.data_csv).query("astronaut_id == 'A01'")
    feats = build_features(df)
    assert not feats[[c for c in FEATURE_COLS if c.endswith(("_z", "_d1"))]].isna().any().any()


def test_normal_day_is_green(client):
    aid = _new_astronaut(client)
    out = _log_days(client, aid, 8)
    assert out["mission_day"] == 8 and out["overall_level"] == "green" and out["alerts"] == []
    assert out["assessment"]["predicted_condition"] == "normal"


@pytest.mark.parametrize("override,condition,metric", [
    (dict(body_temp_c=38.9, heart_rate_bpm=76, resp_rate_bpm=17.5, sleep_hours=6.2), "fever", "body_temp_c"),
    (dict(heart_rate_bpm=104, hrv_ms=38, resp_rate_bpm=16), "tachycardia", "heart_rate_bpm"),
    (dict(cabin_co2_mmhg=7.2, spo2_pct=91.5, resp_rate_bpm=19, heart_rate_bpm=70), "hypoxia_co2", "spo2_pct"),
    (dict(blood_glucose_mgdl=175), "hyperglycemia", "blood_glucose_mgdl"),
    (dict(systolic_bp=158, diastolic_bp=96), "hypertension", "systolic_bp"),
    (dict(sleep_hours=2.8, sleep_quality=2, mood_score=3.2, stress_level=7.5), "sleep_deprivation_low_mood", "sleep_hours"),
])
def test_conditions_detected(client, override, condition, metric):
    aid = _new_astronaut(client)
    _log_days(client, aid, 8)
    out = client.post("/api/v1/readings", json={"astronaut_id": aid, **NORMAL, **override}).json()
    assert out["overall_level"] in ("amber", "red")
    assert out["assessment"]["predicted_condition"] == condition
    assert out["assessment"]["risk_score"] >= 50
    assert metric in {a["metric"] for a in out["alerts"]} | {d["vital"] for d in out["assessment"]["top_deviations"]}
    assert all(a["guidance"] for a in out["alerts"])


def test_personal_baseline_catches_what_thresholds_miss(client):
    """HR 96 is inside every static threshold, but it is +34 bpm for this astronaut."""
    aid = _new_astronaut(client)
    _log_days(client, aid, 8)
    out = client.post("/api/v1/readings", json={"astronaut_id": aid, **NORMAL, "heart_rate_bpm": 96, "hrv_ms": 40}).json()
    assert not [a for a in out["alerts"] if a["source"] == "threshold"]
    assert [a for a in out["alerts"] if a["source"] == "ml"] and out["assessment"]["risk_level"] != "green"


def test_partial_reading_accepted(client):
    aid = _new_astronaut(client)
    r = client.post("/api/v1/readings", json={"astronaut_id": aid, "heart_rate_bpm": 64, "mood_score": 7})
    assert r.status_code == 201 and r.json()["assessment"]["risk_level"] == "green"


def test_validation_and_404(client):
    assert client.post("/api/v1/readings", json={"astronaut_id": "A01", "heart_rate_bpm": 900}).status_code == 422
    assert client.post("/api/v1/readings", json={"astronaut_id": "NOPE", "heart_rate_bpm": 60}).status_code == 404
    assert client.get("/api/v1/astronauts/NOPE/dashboard").status_code == 404
    assert client.get("/api/v1/astronauts/A01/series/not_a_metric").status_code == 400
    assert client.post("/api/v1/astronauts", json={"id": "A01", "name": "Dup", "age": 40, "sex": "M"}).status_code == 400


# ---------------------------------------------------------------- dashboard
def test_radiation_accumulates_and_alerts(client):
    aid = _new_astronaut(client)
    _log_days(client, aid, 5)
    out = client.post("/api/v1/readings", json={"astronaut_id": aid, **NORMAL, "daily_radiation_msv": 14}).json()
    assert out["reading"]["cum_radiation_msv"] == pytest.approx(5 * 0.6 + 14)
    assert any(a["metric"] == "daily_radiation_msv" and a["level"] == "red" for a in out["alerts"])


def test_dashboard_hazards_forecast(client):
    d = client.get("/api/v1/astronauts/A01/dashboard").json()
    assert d["mission_day"] == 120 and d["overall_level"] in ("green", "amber", "red")
    assert [h["hazard"] for h in d["hazards"]] == ["Space Radiation", "Isolation and Confinement", "Distance from Earth",
                                                   "Gravity Fields", "Hostile/Closed Environments"]
    bone, rad = d["forecast"]["bone_density"], d["forecast"]["radiation"]
    assert 0.3 < bone["loss_pct_per_month"] < 3 and bone["projected_end_of_mission_pct"] < bone["current_pct"]
    assert rad["projected_end_of_mission_msv"] > rad["cumulative_msv"] > 0
    assert d["engagement"]["logging_streak_days"] == 120 and len(d["engagement"]["badges"]) == 6
    assert len(d["risk_history"]["risk_scores"]) == 30
    assert "NaN" not in json.dumps(d)


def test_series_readings_alerts_endpoints(client):
    s = client.get("/api/v1/astronauts/A02/series/heart_rate_bpm?days=14").json()
    assert len(s["values"]) == len(s["mission_days"]) == 14 and s["mission_days"][-1] == 120
    assert len(client.get("/api/v1/astronauts/A02/readings?days=5").json()) == 5
    assert isinstance(client.get("/api/v1/astronauts/A02/alerts?days=30").json(), list)
    assert len(client.get("/api/v1/astronauts/A02/hazards").json()) == 5
    assert "radiation" in client.get("/api/v1/astronauts/A02/forecast").json()


def test_empty_astronaut_dashboard(client):
    aid = _new_astronaut(client)
    d = client.get(f"/api/v1/astronauts/{aid}/dashboard").json()
    assert d["mission_day"] == 0 and d["latest_reading"] is None and d["reminders"][0]["id"] == "first_log"


def test_symptoms_body_map(client):
    r = client.post("/api/v1/symptoms", json={"astronaut_id": "A01", "body_part": "Lower_Back", "severity": 6, "description": "ache after exercise"})
    assert r.status_code == 201 and r.json()["mission_day"] == 120
    got = client.get("/api/v1/astronauts/A01/symptoms").json()
    assert got[0]["body_part"] == "lower_back"
    assert client.get("/api/v1/astronauts/A01/dashboard").json()["recent_symptoms"][0]["severity"] == 6


# ---------------------------------------------------------------- LLM
def test_chat_uses_llm(client):
    r = client.post("/api/v1/assistant/chat", json={"astronaut_id": "A01", "message": "How is my sleep?",
                                                    "history": [{"role": "user", "content": "hi"}, {"role": "assistant", "content": "hello"}]})
    assert r.status_code == 200 and r.json() == {"reply": "mock reply from model-a", "source": "llm", "model": "model-a",
                                                 "disclaimer": r.json()["disclaimer"]}


def test_llm_falls_back_to_next_model_when_retired(engine):
    def handler(req):
        return httpx.Response(404, json={"error": {"code": "model_not_found"}}) if json.loads(req.content)["model"] == "model-a" else _ok(req)
    with TestClient(create_app(db_path=":memory:", llm=_llm(handler), engine=engine)) as c:
        assert c.get("/api/v1/astronauts/A01/summary").json()["model"] == "model-b"


def test_offline_fallback_when_no_link(engine):
    with TestClient(create_app(db_path=":memory:", llm=_llm(_down), engine=engine)) as c:
        aid = _new_astronaut(c)
        _log_days(c, aid, 8)
        c.post("/api/v1/readings", json={"astronaut_id": aid, **NORMAL, "body_temp_c": 39.1, "heart_rate_bpm": 78})
        out = c.post("/api/v1/assistant/chat", json={"astronaut_id": aid, "message": "What should I do?"}).json()
        assert out["source"] == "offline" and "Body temperature" in out["reply"] and "flight surgeon" in out["reply"]
        assert c.get("/api/v1/assistant/status").json()["reachable"] is False


# ---------------------------------------------------------------- telemetry, standards, wellbeing, export
def test_bundled_telemetry_stream_is_ingested(client):
    crew = {a["id"]: a for a in client.get("/api/v1/astronauts").json()}
    assert {"ASTRO-01", "ASTRO-02", "ASTRO-03"} <= set(crew) and crew["ASTRO-01"]["mission_day"] == 7
    assert crew["ASTRO-01"]["mission_start"] == "2026-11-08"
    raw = client.get("/api/v1/astronauts/ASTRO-01/telemetry?limit=1000").json()
    assert len(raw) == 48
    day1 = client.get("/api/v1/astronauts/ASTRO-01/readings?days=30").json()[0]
    first_day = [r["heart_rate_bpm"] for r in raw if r["ts"].startswith("2026-11-08")]
    assert day1["heart_rate_bpm"] == pytest.approx(sum(first_day) / len(first_day), abs=0.01)
    assert day1["assessment"]["risk_level"] in ("green", "amber", "red")


def test_live_telemetry_updates_daily_record(client):
    aid = _new_astronaut(client)
    _log_days(client, aid, 8)
    samples = [{"astronaut_id": aid, "timestamp": f"2026-12-01T0{h}:00:00", "heart_rate_bpm": hr, "spo2_pct": 98, "body_temp_c": 36.6}
               for h, hr in enumerate([60, 64, 62])]
    out = client.post("/api/v1/telemetry", json={"samples": samples})
    assert out.status_code == 201 and out.json()["samples_stored"] == 3
    latest = out.json()["latest"][0]
    assert latest["mission_day"] == 9 and latest["reading"]["heart_rate_bpm"] == 62 and latest["overall_level"] == "green"
    spike = client.post("/api/v1/telemetry", json={"samples": [
        {"astronaut_id": aid, "timestamp": "2026-12-02T03:00:00", "heart_rate_bpm": 128, "spo2_pct": 97, "body_temp_c": 36.7}]}).json()["latest"][0]
    assert spike["mission_day"] == 10 and spike["overall_level"] == "red"
    assert client.post("/api/v1/telemetry", json={"samples": [{"astronaut_id": "NOPE", "heart_rate_bpm": 60}]}).status_code == 404


def test_mission_standards_drive_alerts(client):
    std = client.get("/api/v1/reference/standards").json()
    assert std["daily_radiation_msv"]["warning_high"] == 1.0 and std["heart_rate_bpm"]["warning_low"] == 50.0
    aid = _new_astronaut(client)
    out = client.post("/api/v1/readings", json={"astronaut_id": aid, **NORMAL, "daily_radiation_msv": 1.4}).json()
    hit = [a for a in out["alerts"] if a["metric"] == "daily_radiation_msv"]
    assert hit and hit[0]["level"] == "amber" and "mission warning band" in hit[0]["message"]


def test_nasa_study_reference(client):
    s = client.get("/api/v1/reference/nasa-study").json()
    assert s["accession"] == "OSD-665" and "Mus musculus" in s["organisms"] and "not used to train" in s["how_it_is_used"]


def test_wellbeing_checkin_and_reminders(client):
    assert len(client.get("/api/v1/wellbeing/questions").json()["items"]) == 5
    before = {r["id"] for r in client.get("/api/v1/astronauts/A01/reminders").json()}
    assert {"daily_log", "wellbeing_checkin"} <= before
    r = client.post("/api/v1/wellbeing", json={"astronaut_id": "A01", "low_mood": 3, "poor_sleep": 3, "stress_overload": 2,
                                                "feeling_isolated": 2, "trouble_focusing": 1})
    assert r.status_code == 201 and r.json()["score"] == 11 and r.json()["level"] == "red" and len(r.json()["main_concerns"]) == 4
    after = {x["id"] for x in client.get("/api/v1/astronauts/A01/reminders").json()}
    assert "wellbeing_checkin" not in after
    assert client.get("/api/v1/astronauts/A01/dashboard").json()["wellbeing"]["score"] == 11
    assert client.post("/api/v1/wellbeing", json={"astronaut_id": "A01", "low_mood": 9, "poor_sleep": 0, "stress_overload": 0,
                                                   "feeling_isolated": 0, "trouble_focusing": 0}).status_code == 422


def test_crew_overview_sorted_by_urgency(client):
    aid = _new_astronaut(client)
    _log_days(client, aid, 8)
    client.post("/api/v1/readings", json={"astronaut_id": aid, **NORMAL, "body_temp_c": 39.2, "heart_rate_bpm": 80})
    crew = client.get("/api/v1/crew/overview").json()
    levels = [c["overall_level"] for c in crew]
    assert levels == sorted(levels, key=["red", "amber", "green"].index) and levels[0] == "red"
    assert next(c for c in crew if c["astronaut_id"] == aid)["predicted_condition"] == "fever"


def test_export_json_and_csv(client):
    rec = client.get("/api/v1/astronauts/A03/export").json()
    assert len(rec["readings"]) == 120 and rec["astronaut"]["id"] == "A03" and "NaN" not in json.dumps(rec)
    csv_ = client.get("/api/v1/astronauts/A03/export?format=csv")
    assert csv_.headers["content-type"].startswith("text/csv") and len(csv_.text.strip().splitlines()) == 121
    assert client.get("/api/v1/astronauts/A03/export?format=xml").status_code == 422
