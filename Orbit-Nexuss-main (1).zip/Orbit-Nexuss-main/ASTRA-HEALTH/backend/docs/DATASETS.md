# Datasets used by ASTRA-HEALTH

| File | What it is | How the backend uses it |
|---|---|---|
| `data/astronaut_health.csv` | **Synthetic** mission dataset: 24 astronauts x 180 days, 27 columns, labelled episodes | Trains and evaluates the ML engine; seeds demo crew A01-A04 |
| `data/external/simulated/astronaut_telemetry_stream.csv` | **Simulated** hourly wearable stream, 150 samples, 3 crew, 7 days | Ingested at startup through `POST /telemetry` logic; rolled up to daily records for ASTRO-01..03 |
| `data/external/documentation/astronaut_baseline_standards.csv` | Team mission warning bands for 7 parameters | Second alert layer (`GET /reference/standards`) |
| `data/external/nasa/OSD-665_metadata.json` | **Real** NASA OSDR study record | Scientific context (`GET /reference/nasa-study`) |
| `data/external/documentation/anomaly_detection_report.csv` | Earlier threshold scan of the telemetry stream | Kept for reference only |
| `data/reference/sleep_health_lifestyle_kaggle.csv` | Kaggle "Sleep Health and Lifestyle" (synthetic) | Calibrates sleep -> stress -> heart-rate couplings in the generator |

## Two corrections to state accurately in the pitch

1. **OSD-665 is a mouse study, not astronaut data.** Its title is "Transcriptional profiling of right extensor digitorum
   longus muscle from mice flown on the RR-23 mission" (Rodent Research-23, SpaceX-21, 38 days on the ISS, RNA-seq).
   It is not the SOMA / Inspiration4 astronaut atlas. Use it as evidence for muscle changes in microgravity
   (the Gravity Fields hazard), not as a source of human vital signs.
2. **All vital-sign data is simulated.** Real astronaut medical records are restricted (LSAH), which is normal for this
   challenge. Say "trained on simulated mission data designed from published spaceflight physiology".

The five rows in `anomaly_detection_report.csv` do not cross any band in the standards file, so the backend does not
reproduce them; it applies the standards file directly instead.

The warning bands in the standards file are the team's own values. NASA-STD-3001 is the right document to cite for
crew health standards in general, but do not present these specific numbers as quoted from it unless you check them.
