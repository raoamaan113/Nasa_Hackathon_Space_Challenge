# ASTRA-HEALTH - pitch and demo notes

## One line
An on-board health companion that learns each astronaut's own normal, warns early when it changes, explains why in
plain language, and keeps working with no link to Earth.

## 3-minute demo (run `python scripts/demo.py` with the server up)
1. **Baseline** - 8 normal days are logged; the engine learns this astronaut's personal baseline.
2. **Early warning** - day 10: temperature 37.9 C. No red threshold is crossed, but the ML engine goes red: "pattern: fever",
   and lists the three vitals that moved most against the personal baseline.
3. **Closed environment** - day 12: cabin CO2 6.8 mmHg with SpO2 92.5 %. The engine names it a cabin-air pattern, not an illness.
4. **Radiation** - day 13: a 12.5 mSv day. The dose is added to the lifetime record and the Space Radiation hazard turns red.
5. **Five hazards** - one call returns green/amber/red for each NASA hazard.
6. **Assistant** - ask "what should I do today?". Pull the network cable: the answer still comes, from on-board rules.

## Challenge objectives -> where they live
| Objective in the brief | Backend feature |
|---|---|
| Record HR, BP, glucose, temperature, sleep, mood | `POST /readings` (20 optional fields), `POST /telemetry` for wearables |
| Organised, understandable data | `/dashboard`, `/series/{metric}`, `/readings`, `/export` |
| Recognise unusual changes | personal-baseline ML + colour-coded thresholds + mission standards |
| Accessible guidance | every alert carries a next step; LLM chat and daily briefing |
| Body map | `POST /symptoms` |
| Reminders and notifications | `/reminders` |
| Gamification | logging streak and six badges in `/dashboard` |
| Decision support, not diagnosis | stated in every assistant reply and enforced in the system prompt |

## The five hazards
| Hazard | What the system does |
|---|---|
| Space Radiation | daily and cumulative dose, % of the 600 mSv career limit, end-of-mission projection, solar-event alert |
| Isolation and Confinement | mood, sleep, stress trends; 5-question weekly check-in; ML pattern "sleep deprivation + low mood" |
| Distance from Earth | on-board SQLite record, full export, offline assistant, reminders with no ground contact |
| Gravity Fields | bone-density loss rate and projection, exercise adherence, resting-HR drift, body mass |
| Hostile/Closed Environments | cabin CO2, temperature, humidity logged with vitals; ML pattern "hypoxia / CO2" |

## The 10 study-guide questions, in one line each
1. Physical + psychological monitoring: vitals, sleep, mood, stress, check-ins and symptoms in one record.
2. Key indicators: HR, HRV, BP, SpO2, temperature, glucose, sleep, mood, stress, bone density, radiation dose, cabin CO2.
3. Spotting unusual change: z-score against the astronaut's own 14-day baseline, plus absolute thresholds.
4. Five hazards: one status per hazard, each with its own metrics.
5. Communication delays: everything is stored and computed on board; the LLM is optional.
6. Simple visuals: chart-ready series and a single 0-100 risk score with green/amber/red.
7. Reminders: generated from the record itself (missed logs, short sleep, low exercise, overdue check-in).
8. Reliable guidance without diagnosis: fixed, reviewed guidance text per alert; the LLM is grounded in the data and told never to diagnose.
9. Sleep, mood, behavioural health: daily logs, weekly check-in, trend slopes, dedicated ML class.
10. User-friendly and reliable: every field optional, partial data accepted, 28 automated tests, graceful offline mode.

## Numbers you can quote (and how to say them)
- ML on 6 astronauts never seen in training: ROC-AUC 0.99, macro-F1 0.94; the unsupervised model alone: ROC-AUC 0.93.
- Say: "on simulated mission data". Do not call it clinical accuracy.
- 25 API endpoints, 28 passing tests, starts in about 3 seconds.

## Honest limits (judges respect these)
- Vital-sign data is simulated; the NASA OSDR file is a rodent study used as scientific context.
- Alert thresholds are screening values chosen by the team, not flight rules.
- It supports decisions; it does not replace the flight surgeon.
