# ASTRA-HEALTH - backend + ML engine + LLM

NASA Space Apps, Challenge 4: health monitoring software for astronauts.
FastAPI backend, SQLite storage, a two-model ML engine and a Groq LLM assistant with an offline fallback.
**Decision support only - not a medical diagnosis.**

## Run it (3 commands)

```bash
pip install -r requirements.txt
python scripts/check_llm.py          # confirms the Groq key + live model names
uvicorn app.main:app --reload        # http://localhost:8000/docs  (interactive API)
```

First start seeds 4 demo astronauts (A01-A04) at mission day 120 and ingests the bundled telemetry stream
(ASTRO-01..03, 7 days). Run `python scripts/demo.py` for the judge demo. Delete `data/astrohealth.db` to reset.
Run the tests with `pytest -q`. Regenerate data / retrain with
`python scripts/generate_data.py && python scripts/train.py`.

## Layout

```
app/main.py              app factory, startup (load model, seed crew)
app/api/routes.py        REST endpoints
app/services/monitor.py  orchestration: store -> ML -> alerts -> LLM context
app/services/rules.py    colour-coded thresholds + plain-language guidance
app/services/analytics.py trends, forecasts, five-hazard mapping, badges
app/services/llm.py      Groq client, model fallback, offline reply
app/ml/features.py       personal-baseline features (shared by train + serve)
app/ml/engine.py         IsolationForest + gradient-boosting classifier, risk score
app/services/reference.py mission standards CSV + NASA OSDR study record
scripts/                 generate_data.py, train.py, check_llm.py, demo.py
docs/                    PITCH.md (demo + talking points), DATASETS.md
data/astronaut_health.csv  24 astronauts x 180 days, 27 columns (synthetic)
```

## API (25 endpoints, interactive docs at `/docs`)

| Method | Path | Notes |
|---|---|---|
| POST | `/api/v1/assistant/chat` | Chat |
| GET | `/api/v1/assistant/status` | Is the LLM reachable, and which models are live? |
| GET | `/api/v1/astronauts` | List Astronauts |
| POST | `/api/v1/astronauts` | Create Astronaut |
| GET | `/api/v1/astronauts/{astronaut_id}/alerts` | Alerts |
| GET | `/api/v1/astronauts/{astronaut_id}/dashboard` | Everything the home screen needs in one call |
| GET | `/api/v1/astronauts/{astronaut_id}/export` | Full health record (JSON or CSV) |
| GET | `/api/v1/astronauts/{astronaut_id}/forecast` | Forecast |
| GET | `/api/v1/astronauts/{astronaut_id}/hazards` | NASA's five spaceflight hazards |
| GET | `/api/v1/astronauts/{astronaut_id}/readings` | Readings |
| GET | `/api/v1/astronauts/{astronaut_id}/reminders` | Reminders and notifications |
| GET | `/api/v1/astronauts/{astronaut_id}/series/{metric}` | Chart-ready time series |
| GET | `/api/v1/astronauts/{astronaut_id}/summary` | LLM daily health briefing (offline fallback built in) |
| GET | `/api/v1/astronauts/{astronaut_id}/symptoms` | List Symptoms |
| GET | `/api/v1/astronauts/{astronaut_id}/telemetry` | Raw sensor samples (latest N) |
| GET | `/api/v1/astronauts/{astronaut_id}/wellbeing` | List Wellbeing |
| GET | `/api/v1/crew/overview` | Whole-crew status, most urgent first |
| GET | `/api/v1/ml/metrics` | Ml Metrics |
| POST | `/api/v1/readings` | Log a daily reading -> instant ML assessment + colour-coded alerts |
| GET | `/api/v1/reference/nasa-study` | Bundled NASA OSDR study (scientific context) |
| GET | `/api/v1/reference/standards` | Mission warning bands used for alerts |
| POST | `/api/v1/symptoms` | Body-map symptom entry |
| POST | `/api/v1/telemetry` | Ingest wearable/sensor samples -> rolled up into the daily record and re-scored |
| POST | `/api/v1/wellbeing` | Weekly 5-question well-being check-in |
| GET | `/api/v1/wellbeing/questions` | Wellbeing Questions |
| GET | `/health` | Health |

## How the ML works

1. **Personal baseline.** Each vital is compared with that astronaut's own rolling 14-day median (z-score) plus the day-over-day change.
2. **IsolationForest** (unsupervised) scores how unusual the day is. It needs no labels, so it also flags patterns never seen before.
3. **HistGradientBoosting classifier** names the pattern: fever, tachycardia, hypertension, hyperglycemia, hypoxia/CO2, sleep deprivation + low mood.
4. Both are blended into a **0-100 risk score** (green < 35, amber < 65, red). Threshold rules run alongside for absolute danger values.

Held-out result (6 astronauts never seen in training): anomaly ROC-AUC 0.99, macro-F1 0.94; IsolationForest alone ROC-AUC 0.93.
These numbers are on **synthetic** data and are not a clinical accuracy claim. See `models/metrics.json`.

## The dataset

Real astronaut vitals are not public, so `scripts/generate_data.py` simulates them: personal baselines, microgravity
adaptation, exercise-dependent bone loss (~1 %/month), a mid-mission mood/sleep dip, a cabin environment shared by each
crew of four (CO2 excursions, solar particle events) and multi-day medical episodes with an onset ramp.
Sleep -> stress -> heart-rate couplings are fitted on the Kaggle "Sleep Health and Lifestyle" table (itself synthetic).

See `docs/DATASETS.md` for every bundled file and two corrections to make in the pitch.

## Security

`.env` holds the Groq key and is git-ignored. The key was shared in a chat, so rotate it after the hackathon.
