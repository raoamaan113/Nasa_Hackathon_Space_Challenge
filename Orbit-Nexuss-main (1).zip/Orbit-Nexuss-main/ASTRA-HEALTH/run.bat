@echo off
cd /d "%~dp0backend"
python -m pip install -r requirements.txt
start "" http://localhost:8000
python -m uvicorn app.main:app --port 8000
