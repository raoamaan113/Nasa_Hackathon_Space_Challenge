#!/bin/sh
cd "$(dirname "$0")/backend" && pip install -r requirements.txt && python -m uvicorn app.main:app --port 8000
