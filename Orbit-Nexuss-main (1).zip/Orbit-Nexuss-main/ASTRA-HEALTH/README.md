# ASTRA-HEALTH

Health monitoring software for astronauts - NASA Space Apps, Challenge 4.
React UI + FastAPI backend + ML engine + Groq LLM assistant, shipped as **one app**: the backend serves the UI.
Decision support only - not a medical diagnosis. Vital-sign data is simulated.

## Run locally (Python 3.10+ only, Node is not needed)

Windows: double-click `run.bat`. Or by hand:

```
cd backend
pip install -r requirements.txt
python -m uvicorn app.main:app --port 8000
```

Open http://localhost:8000 (UI) and http://localhost:8000/docs (API).
Check the LLM key with `python scripts/check_llm.py`; without a working key the assistant answers in offline mode.

## Deploy (one web service)

**Render:** push this folder to GitHub, then New + > Blueprint > select the repo (`render.yaml` is included).
Add `GROQ_API_KEY` under Environment. Manual settings if you prefer: Root Directory `backend`,
Build `pip install -r requirements.txt`, Start `python -m uvicorn app.main:app --host 0.0.0.0 --port $PORT`.

**Docker (Railway, Fly, Hugging Face Spaces, any VM):**
`docker build -t astra-health . && docker run -p 8000:8000 -e GROQ_API_KEY=... astra-health`

`.env` is git-ignored on purpose, so set `GROQ_API_KEY` in the host's environment settings.
The database is SQLite and is re-seeded with the demo crew on a fresh start.

## Pages

| Page | What it does |
|---|---|
| Dashboard | overall status, ML risk score, vitals, alerts with next steps, five hazards, forecasts, badges, AI briefing |
| Monitoring | any metric over time, live sensor sample (wearable ingestion), recent records |
| Assessment | daily log with demo presets, instant ML assessment, weekly well-being check-in |
| Human Body | interactive body map symptom log |
| Guidance & AI | assistant chat grounded in the record, reminders, guidance per alert |
| Reports | crew overview, full history, CSV/JSON export, ML performance, NASA study reference |

## Develop the UI

```
cd frontend && npm install
npm run dev      # http://localhost:5173, proxies /api to :8000
npm run build    # writes the production build into backend/static
```

## Tests

`cd backend && python -m pytest -q` (28 API/ML tests). More detail: `backend/README.md`, `backend/docs/PITCH.md`, `backend/docs/DATASETS.md`.
